<template>
  <div :class="['loading-screen', { active: isActive }]">
    <slot />
  </div>
</template>

<script>
export default {
  props: {
    isActive: {
      type: Boolean,
      default: false,
    },
  },
}
</script>

<style lang="scss">
.loading-screen {
  display: none;

  &.active {
    display: block;
  }
}

.main-image {
  height: 100px;
  width: auto;
  margin: 60px auto;
  display: block;
}

.bottom-image {
  height: 160px;
  width: auto;
}
</style>
