<template>
  <div>
    <h1>
      Finding {{ userName() }}'s
      <br>
      <span class="color-teal">awesome-possum-ist</span> {{ gradeName() }}...
    </h1>
    <img class="main-image" src="/finding-giraffe.svg">
    <img class="bottom-image" src="/loading1-bottom.png">
  </div>
</template>

<script>
import LoadingScreen from '../Screen'

export default {
  extends: LoadingScreen,
  methods: {
    userName() {
      return this.$store.state.user.fields.name
    },
    gradeName() {
      return this.$store.getters['user/gradeName']
    },
  },
}
</script>

<style>
</style>
