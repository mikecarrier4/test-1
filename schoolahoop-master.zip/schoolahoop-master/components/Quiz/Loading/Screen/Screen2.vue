<template>
  <div>
    <h1>
      <span class="color-teal">Select</span>
      the schools
      <br>
      you want
    </h1>
    <img class="main-image" src="/deselect.png">
    <img class="bottom-image" src="/loading2-bottom.png">
  </div>
</template>

<script>
import LoadingScreen from '../Screen'

export default {
  extends: LoadingScreen,
}
</script>

<style>
</style>
