<template>
  <div>
    <h1>
      We'll put you
      <br>
      <span class="color-teal">in touch</span>
    </h1>
    <img class="main-image" src="/sharing.svg">
    <img class="bottom-image" src="/loading4-bottom.png">
  </div>
</template>

<script>
import LoadingScreen from '../Screen'

export default {
  extends: LoadingScreen,
}
</script>

<style>
</style>
