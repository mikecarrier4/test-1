<template>
  <div>
    <h1>
      We'll
      <span class="color-teal">share your preferences</span>
      with these schools
    </h1>
    <img class="main-image" src="/paper-airplanes.png">
    <img class="bottom-image" src="/loading3-bottom.png">
  </div>
</template>

<script>
import LoadingScreen from '../Screen'

export default {
  extends: LoadingScreen,
}
</script>

<style>
</style>
