<template>
  <div>
    <h1>
      What is your
      <span class="color-teal">family's home</span>
      address?
    </h1>
    <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'paragraph',
          text: 'We use this to find nearby options within your school district.'
        },
        {
          type: 'google_autocomplete',
          name: 'home_address',
          placeholder: 'Type address',
        }
      ],
    }
  },
  mounted() {
  },
}
</script>

<style>
</style>
