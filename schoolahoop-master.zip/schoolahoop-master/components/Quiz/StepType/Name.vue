<template>
  <div>
    <h1>
      First things first.
      <br>
      What is your <span class="color-teal">kiddo's name</span>?
    </h1>
    <div class="emojis">
      <img src="/purple-smile-emoji.svg">
      <img src="/yellow-derpy-emoji.svg">
      <img src="/salmon-glasses-emoji.svg">
      <img src="/teal-sleepy-emoji.svg">
    </div>
    <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'textInput',
          name: 'name',
          placeholder: 'Type child\'s name here',
        },
      ],
    }
  },
}
</script>

<style lang="scss">
.emojis {
  margin: 40px 0;

  img {
    display: inline-block;
    margin: 10px;
    height: 75px;
    width: 75px;
  }
}
</style>
