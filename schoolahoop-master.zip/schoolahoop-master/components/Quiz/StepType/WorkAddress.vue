<template>
  <div>
    <h1>
      Where do you work?
    </h1>
    <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      title: '',
      elements: [
        {
          type: 'google_autocomplete',
          name: 'work_address',
          placeholder: 'Type address',
        },
      ],
    }
  },
}
</script>

<style>
</style>
