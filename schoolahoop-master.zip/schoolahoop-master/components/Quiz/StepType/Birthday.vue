<template>
  <div>
    <h1>
      When is {{ userName() }}'s birthday?
    </h1>
    <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'date',
          name: 'birthday',
          placeholder: 'Select date here',
        },
      ],
    }
  },
}
</script>

<style>
</style>
