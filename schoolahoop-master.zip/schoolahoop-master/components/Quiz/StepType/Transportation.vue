<template>
  <div>
    <h1>
      How would you like {{ userName() }}
      <span class="color-teal">to get to school</span>?
    </h1>
    <elements-renderer class="transportation-selector" :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'selector',
          name: 'transportation',
          label: 'Transportation',
          multiple: true,
          numOptionsPerRow: 3,
          options: [
            {
              'type': 'imageToggle',
              'value': 'driving',
              'imageSrc': '/driving.png',
              'label': 'Driving'
            },
            {
              'type': 'imageToggle',
              'value': 'public',
              'imageSrc': '/public_transportation.svg',
              'label': 'Public Transport'
            },
            {
              'type': 'imageToggle',
              'value': 'school bus',
              'imageSrc': '/bus.svg',
              'label': 'School Bus'
            },
            {
              'type': 'imageToggle',
              'value': 'walking',
              'imageSrc': '/walking.svg',
              'label': 'Walking'
            },
            {
              'type': 'imageToggle',
              'value': 'biking',
              'imageSrc': '/bike.svg',
              'label': 'Biking'
            },
          ],
        },
      ],
    }
  },
}
</script>

<style>
  .transportation-selector {
    margin: auto;
    max-width: 580px;
  }
</style>
