<template>
  <div>
    <h1>
      <span class="color-teal">How much time</span>
      are you willing to add to your
      <span class="color-teal">morning commute</span>?
    </h1>
    <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'selector',
          name: 'max_travel_time',
          label: 'Commute Time',
          options: [
            {
              type: 'pill',
              value: '30 min or less',
              borderColor: '#f3d239',
              label: '30 min or less',
              isSelected: true,
            },
            {
              type: 'pill',
              value: '60 min or less',
              borderColor: '#ffae94',
              label: '60 min or less',
              isSelected: true,
            },
            {
              type: 'pill',
              value: '90 min or less',
              borderColor: '#4fc5d5',
              label: '90 min or less',
              isSelected: true,
            },
            {
              type: 'pill',
              value: 'Time is not an issue',
              borderColor: '#a594f0',
              label: 'Time is not an issue',
              isSelected: true,
            },
          ],
        },
      ],
    }
  },
}
</script>

<style>
</style>
