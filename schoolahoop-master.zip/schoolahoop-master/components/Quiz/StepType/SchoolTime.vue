<template>
  <div>
    <h1>
      {{ userName() }}'s a busy kid!
      <span class="color-teal">How much time</span>
      can they spend getting to school?
    </h1>
    <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'selector',
          name: 'max_travel_time',
          label: 'Time to School',
          options: [
            {
              type: 'pill',
              value: '20 min or less',
              borderColor: '#f3d239',
              label: '20 min or less',
              isSelected: true,
            },
            {
              type: 'pill',
              value: '40 min or less',
              borderColor: '#ffae94',
              label: '40 min or less',
              isSelected: true,
            },
            {
              type: 'pill',
              value: '60 min or less',
              borderColor: '#4fc5d5',
              label: '60 min or less',
              isSelected: true,
            },
            {
              type: 'pill',
              value: 'Time is not an issue',
              borderColor: '#a594f0',
              label: 'Time is not an issue',
              isSelected: true,
            },
          ],
        },
      ],
    }
  },
}
</script>

<style>
</style>
