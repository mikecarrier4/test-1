<template>
  <div>
    <h1>
      What grade is
      <span class="color-teal">{{ userName() }} going into</span>?
    </h1>
    <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'paragraph',
          text: 'Use the slider to select a grade.',
        },
        {
          type: 'slider',
          name: 'grade',
          loaded_value: this.getLoadedValue(),
          options: [
            {
              value: 'K',
              label: 'K',
              tooltip: 'Kindergarten',
            },
            {
              value: '1st',
              label: '1st',
              tooltip: '1st grade',
            },
            {
              value: '2nd',
              label: '2nd',
              tooltip: '2nd grade',
            },
            {
              value: '3rd',
              label: '3rd',
              tooltip: '3rd grade',
            },
            {
              value: '4th',
              label: '4th',
              tooltip: '4th grade',
            },
            {
              value: '5th',
              label: '5th',
              tooltip: '5th grade',
            },
          ],
        }
      ],
    }
  },
  methods: {
    getLoadedValue() {
      if (this.$store.state.user.fields.grade) {
        return this.$store.state.user.fields.grade
      } else {
        return 'K'
      }
    },
  }
}
</script>

<style lang="scss">
.emojis {
  margin: 40px 0;

  img {
    display: inline-block;
    margin: 10px;
    height: 75px;
    width: 75px;
  }
}
</style>
