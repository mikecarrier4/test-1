<template>
  <div>
      <h1>
        Do you want us <span class="color-teal">to consider schools</span> along your morning work commute?
      </h1>
      <elements-renderer :elements="elements" />
  </div>
</template>

<script>
import StepType from '../StepType'

export default {
  extends: StepType,
  data() {
    return {
      elements: [
        {
          type: 'selector',
          name: 'consider_commute',
          label: 'Consider commute',
          options: [
            {
              type: 'smiley',
              value: false,
              label: 'No',
              description: 'No, Thanks!',
              imageSrc: '/sleep-face.svg'
            },
            {
              type: 'smiley',
              value: true,
              label: 'Yes',
              description: 'Yes, Please!',
              imageSrc: '/smile-face.svg',
            },
          ],
        }
      ]
    }
  }
}
</script>