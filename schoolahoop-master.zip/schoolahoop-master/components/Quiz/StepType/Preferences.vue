<template>
  <div>
    <h1>
      What
      <span class="color-teal">matters most</span>
      for {{ userName() }} in a school?
    </h1>
    <elements-renderer v-show="!allOptionsExpanded" class="preferences-selector" :elements="elementsWithLimitedOptions" />
    <elements-renderer v-show="allOptionsExpanded" class="preferences-selector" :elements="elementsWithAllOptions" />
    <Btn 
      v-if="!allOptionsExpanded" 
      class="button button--teal button--block button--small show-more-button" 
      label="Show more" 
      @clicked="expandAll" 
    />
  </div>
</template>

<script>
import Btn from '../../Btn'
import StepType from '../StepType'

export default {
  extends: StepType,
  components: {
    Btn
  },
  data() {
    return {
      allOptions: [
        {
          'type': 'imageToggle',
          'value': 'top_20_safety',
          'imageSrc': '/safety.svg',
          'label': 'Top 20% Safety'
        },
        {
          'type': 'imageToggle',
          'value': 'top_20_score',
          'imageSrc': '/document.svg',
          'label': 'Top 20% Test Scores'
        },
        {
          'type': 'imageToggle',
          'value': 'school_bus_available',
          'imageSrc': '/bus.svg',
          'label': 'School Bus'
        },
        {
          'type': 'imageToggle',
          'value': 'diversity',
          'imageSrc': '/group.svg',
          'label': 'Diversity'
        },
        {
          'type': 'imageToggle',
          'value': 'non_religious',
          'imageSrc': '/planet.svg',
          'label': 'Non-Religious'
        },
        {
          'type': 'imageToggle',
          'value': 'religious',
          'imageSrc': '/angel.svg',
          'label': 'Religious'
        },
        {
          'type': 'imageToggle',
          'value': 'no_spanking',
          'imageSrc': '/bald_frown.svg',
          'label': 'No Spanking'
        },
        {
          'type': 'imageToggle',
          'value': 'after_school_care',
          'imageSrc': '/crayons.svg',
          'label': 'After School Care'
        },
        {
          'type': 'imageToggle',
          'value': 'special_needs_education',
          'imageSrc': '/hand_pencil.svg',
          'label': 'Special Needs Education'
        },
        {
          'type': 'imageToggle',
          'value': 'gifted_student_programs',
          'imageSrc': '/star_glasses.svg',
          'label': 'Gifted Student Programs'
        },
        {
          'type': 'imageToggle',
          'value': 'english_as_second_language',
          'imageSrc': '/presentation.svg',
          'label': 'English as Second Language'
        },
        {
          'type': 'imageToggle',
          'value': 'k12_school',
          'imageSrc': '/figures.svg',
          'label': 'K-12 School'
        },
        {
          'type': 'imageToggle',
          'value': 'school_library',
          'imageSrc': '/apple_books.svg',
          'label': 'Reading'
        },
        {
          'type': 'imageToggle',
          'value': 'foreign_languages',
          'imageSrc': '/languages.svg',
          'label': 'Foreign Languages'
        },
        {
          'type': 'imageToggle',
          'value': 'theater',
          'imageSrc': '/theater.svg',
          'label': 'Theater'
        },
        {
          'type': 'imageToggle',
          'value': 'dance',
          'imageSrc': '/disco.svg',
          'label': 'Dance'
        },
        {
          'type': 'imageToggle',
          'value': 'special_diet',
          'imageSrc': '/food_bowl.svg',
          'label': 'Special Diet'
        },
        {
          'type': 'imageToggle',
          'value': 'visual_arts',
          'imageSrc': '/paint.svg',
          'label': 'Visual Arts'
        },
        {
          'type': 'imageToggle',
          'value': 'computer_science',
          'imageSrc': '/robot.svg',
          'label': 'Computer Science'
        },
        {
          'type': 'imageToggle',
          'value': 'music',
          'imageSrc': '/drums.svg',
          'label': 'Music'
        },
        {
          'type': 'imageToggle',
          'value': 'sports',
          'imageSrc': '/sports.svg',
          'label': 'Sports'
        },
        {
          'type': 'imageToggle',
          'value': 'healthy_lunch_options',
          'imageSrc': '/healthy.svg',
          'label': 'Healthy Lunch Options'
        },
        {
          'type': 'imageToggle',
          'value': 'science',
          'imageSrc': '/science.svg',
          'label': 'Science'
        },
      ],
      allOptionsExpanded: false
    }
  },
  computed: {
    elementsWithLimitedOptions() {
      return [{ 
        type: 'selector',
        name: 'preferences',
        label: 'Preferences',
        multiple: true,
        numOptionsPerRow: 3,
        allowCustomInput: false,
        options: this.allOptions.slice(0, 12)
      }];
    },
    elementsWithAllOptions() {
      return [{ 
        type: 'selector',
        name: 'preferences',
        label: 'Preferences',
        multiple: true,
        numOptionsPerRow: 3,
        allowCustomInput: true,
        options: this.allOptions
      }]
    }
  },
  methods: {
    expandAll() { 
      this.allOptionsExpanded = true
    }
  }
}
</script>

<style lang="scss">
  .preferences-selector {
    margin: auto;
    max-width: 580px;
  }
  .show-more-button {
    margin-top: 40px;
  }
</style>
