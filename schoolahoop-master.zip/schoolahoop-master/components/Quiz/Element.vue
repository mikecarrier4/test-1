<script>
export default {
  props: {
    name: {
      type: String,
      default: '',
    },
    loaded_value: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      value: this.$store.getters['user/fields'](this.name)
    }
  },
  watch: {
    value(val) {
      const obj = {}
      obj.key = this.name
      obj.value = val

      this.$store.commit('user/update', obj)
    },
  },
  methods: {
    toggleTruthy() {
      this.value = !this.value
    },
  },
}
</script>

<style>
</style>
