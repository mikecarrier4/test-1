<template>
  <div class="quiz-loading">
    <LoadingScreen
      v-for="(screen, index) in screens"
      :key="screen"
      :is-active="currentScreenIndex === index"
    >
      <component :is="loadScreen(screen)" />
    </LoadingScreen>
  </div>
</template>

<script>
import LoadingScreen from './Loading/Screen'
import Screen1 from './Loading/Screen/Screen1'
import Screen2 from './Loading/Screen/Screen2'
import Screen3 from './Loading/Screen/Screen3'
import Screen4 from './Loading/Screen/Screen4'

const sleep = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds))
}

export default {
  components: { LoadingScreen, Screen1, Screen2, Screen3, Screen4 },
  props: {
    screenTime: {
      type: Number,
      default: 2000,
    },
  },
  data() {
    return {
      screens: [1, 2, 3, 4],
      currentScreenIndex: 0,
      finishedLoop: false,
    }
  },
  mounted() {
    this.loop()
  },
  methods: {
    loadScreen(num) {
      return `Screen${num}`
    },
    nextScreen() {
      if (this.currentScreenIndex < this.screens.length - 1) {
        this.currentScreenIndex++
      } else {
        this.currentScreenIndex = 0
      }

      return this.currentScreenIndex
    },
    finishLoop() {
      this.finishedLoop = true
      this.$emit('finishedLoadingLoop')
    },
    loop() {
      sleep(this.screenTime).then(() => {
        if (this.currentScreenIndex === this.screens.length - 1) {
          this.finishLoop()
        } else {
          this.nextScreen()
          this.loop()
        }
      })
    }
  },
}
</script>

<style>
</style>
