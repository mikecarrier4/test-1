<template>
  <p class="mw-420">
    {{ text }}
  </p>
</template>

<script>
import QuizElement from '../Element'

export default {
  extends: QuizElement,
  props: {
    text: {
      type: String,
      default: '',
    },
  },
}
</script>

<style>
</style>
