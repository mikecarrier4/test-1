<template>
  <vue-slider
    v-model="value"
    :data="getValues()"
    :tooltip="'always'"
    :marks="true"
    :contained="true"
    :height="60"
    class="slider"
    ref="slider"
  >
    <template v-slot:dot>
      <img src="/smile-face.svg" class="slider__dot">
    </template>
    <template v-slot:tooltip="{ value }">
      <div class="slider__tooltip">
        <span>{{ getTooltip(value) }}</span>
      </div>
    </template>
    <template v-slot:label="{ active, value }">
      <div :class="['vue-slider-mark-label', 'slider__label', { active }]">
        {{ value }}
      </div>
    </template>
    <template v-slot:step="{ label, active }">
      <div :class="['slider__step', { active }]" />
    </template>
  </vue-slider>
</template>

<script>
import VueSlider from 'vue-slider-component'
import QuizElement from '../Element'

export default {
  components: { VueSlider },
  extends: QuizElement,
  props: {
    options: {
      type: Array,
      default: () => [],
    },
  },
  mounted() {
    this.setLoadedValue()
    // this.updateDefaultStoreValue()
  },
  methods: {
    getValues() {
      return this.options.map(key => key.value)
    },
    setLoadedValue() {
      this.$refs.slider.setValue(this.loaded_value)
    },
    getTooltip(val) {
      for (let i = 0; i < this.options.length; i++) {
        const option = this.options[i]

        if (val === option.value) {
          return option.tooltip
        }
      }

      return this.options[0].tooltip
    },
    updateDefaultStoreValue() {
      const obj = {
        key: this.name,
        value: this.options[0].value,
      }

      this.$store.commit('user/update', obj)
    },
  },
}
</script>

<style lang="scss">
.slider {
  margin: 40px 20px;
  padding: 0 30px !important;
  background-color: $teal;
  border-radius: 35px;
  max-width: 400px;

  @media(min-width: 576px) {
    margin: 40px auto;
  }

  &__dot {
    height: 50px;
    width: 50px;
    position: absolute;
    transform: translate(-50%, -50%);
    top: 50%;
    left: 50%;
    box-shadow: 0px 6px 3px 0px rgba(0,0,0,0.2);
    border-radius: 25px;
  }

  &__tooltip {
    color: $teal;
    margin-bottom: 20px;

    span {
      line-height: 1;
      margin: 0;
      padding: 0;
      width: 100px;
      display: block;
    }
  }

  &__label {
    color: $gray;
  }

  &__step {
    background-color: $white;
    height: 12px;
    width: 12px;
    border-radius: 6px;
    top: 50%;
    position: absolute;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: 0.5;
  }
}
</style>
