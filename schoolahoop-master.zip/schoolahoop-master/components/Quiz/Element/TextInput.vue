<template>
  <input
    v-model="value"
    type="text"
    :placeholder="placeholder"
    :name="name"
  ></input>
</template>

<script>
import QuizElement from '../Element'

export default {
  extends: QuizElement,
  props: {
    name: {
      type: String,
      default: '',
    },
    placeholder: {
      type: String,
      default: '',
    },
  },
}
</script>

<style>
</style>
