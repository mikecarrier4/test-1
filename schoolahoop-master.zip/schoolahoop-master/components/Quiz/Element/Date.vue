<template>
  <datepicker
    v-model="value"
    name="birthday"
  />
</template>

<script>
import Datepicker from 'vuejs-datepicker'
import QuizElement from '../Element'

export default {
  components: { Datepicker },
  extends: QuizElement,
  props: {
    name: {
      type: String,
      default: '',
    },
    placeholder: {
      type: String,
      default: '',
    },
  },
}
</script>

<style>
</style>
