<template>
  <div class="autocomplete">
    <input
      v-model="value"
      type="text"
      class="autocomplete__input"
      :placeholder="placeholder"
      @input="db"
      @keydown.down="onArrowDown"
      @keydown.up="onArrowUp"
      @keydown.enter="onEnter"
    >
    <ul
      v-show="isOpen"
      class="autocomplete__results"
    >
      <li
        v-if="isLoading"
        class="loading"
      >
        Loading results...
      </li>
      <li
        v-for="(result, i) in results"
        v-else
        :key="i"
        class="autocomplete__result"
        :class="{ 'active': i === arrowCounter }"
        @click="setResult(result)"
      >
        {{ result }}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'
import debounce from 'debounce'
import QuizElement from '../Element'

export default {
  extends: QuizElement,
  props: {
    placeholder: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      isOpen: false,
      results: [],
      isLoading: false,
      arrowCounter: 0,
      items: [],
    }
  },
  computed: {
    db() {
      return debounce(this.onChange, 400)
    },
  },
  watch: {
    items(val, oldValue) {
      if (val.length !== oldValue.length) {
        this.results = val
        this.isLoading = false
      }
    },
  },
  mounted() {
    document.addEventListener('click', this.handleClickOutside)
  },
  destroyed() {
    document.removeEventListener('click', this.handleClickOutside)
  },
  methods: {
    onChange() {
      this.isLoading = true

      axios.post('/.netlify/functions/google_autocomplete', JSON.stringify({
        query: this.value,
      })).then((results) => {
        this.isLoading = false
        this.results = results.data
        this.isOpen = true
      })
    },
    setResult(result) {
      this.value = result
      this.isOpen = false
    },
    onArrowDown(evt) {
      if (this.arrowCounter < this.results.length) {
        this.arrowCounter = this.arrowCounter + 1
      }
    },
    onArrowUp() {
      if (this.arrowCounter > 0) {
        this.arrowCounter = this.arrowCounter - 1
      }
    },
    onEnter() {
      this.search = this.results[this.arrowCounter]
      this.isOpen = false
      this.arrowCounter = -1
    },
    handleClickOutside(evt) {
      if (!this.$el.contains(evt.target)) {
        this.isOpen = false
        this.arrowCounter = -1
      }
    }
  }
}
</script>

<style lang="scss">
.autocomplete {
  position: relative;

  &__input {
    max-width: 100%;
    width: 600px;
  }

  &__results {
    padding: 20px;
    border: 1px solid $gray;
    height: 200px;
    overflow: auto;
    max-width: 500px;
    margin: 10px auto 30px;
    border-radius: 20px;
    list-style: none;
  }

  &__result {
    list-style: none;
    text-align: center;
    padding: 4px 2px;
    cursor: pointer;

    &.active, &:hover {
      background-color: $teal;
      color: $white;
    }
  }
}
</style>
