<template>
  <div>
    <component
      :is="option.type"
      v-for="(option, index) in options"
      :ref="`option_${index}`"
      :key="index"
      :image-src="option.imageSrc"
      :label="option.label"
      :value="option.value"
      :color="option.color"
      :background-color="option.backgroundColor"
      :border-color="option.borderColor"
      :is-selected="isSelected(option.value)"
      :status="option.status"
      :description="option.description"
      :style="optionStyleOverrides"
      @addValue="addValue"
      @removeValue="removeValue"
      @deSelectAll="deSelectAll"
    />
    <div
      v-if="allowCustomInput"
      class="selector-custom-input"
    >
      <input
        v-model="customOption"
        type="text"
        placeholder="Add another interest"
      ></input>
      <button class="round-button" @click="addCustomOption" :disabled="customTextExists">
        +
      </button>
    </div>
  </div>
</template>

<script>
import Btn from '../../Btn'
import QuizElement from '../Element'
import ImageToggle from './Selector/Option/ImageToggle'
import Pill from './Selector/Option/Pill'
import Smiley from './Selector/Option/Smiley'

const removeValFromArr = (arr, val) => {
  return arr.filter((value, index, arr) => {
    return value !== val
  })
}

export default {
  components: { ImageToggle, Pill, Smiley, Btn },
  extends: QuizElement,
  props: {
    label: {
      type: String,
      default: '',
    },
    multiple: {
      type: Boolean,
      default: false,
    },
    options: {
      type: Array,
      default: () => [],
    },
    numOptionsPerRow: {
      type: Number,
      default: null,
    },
    allowCustomInput: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      customOption: '',
    }
  },
  computed: {
    customTextExists() {
      return (this.customOption.trim() === '') ? true : false
    },
    optionStyleOverrides() {
      return this.numOptionsPerRow 
        ? { width: `${(100 / this.numOptionsPerRow).toFixed(2)}%` } 
        : null
    }
  },
  methods: {
    isSelected(val) {
      const field = this.$store.state.user.fields[this.name]

      if (typeof field === 'object') {
        return field.includes(val)
      }

      return field === val
    },
    optionType(type) {
      if (this.type === 'imageToggle') {
        return 'ImageToggle'
      } else if (this.type === 'pill') {
        return 'Pill'
      } else if (this.type === 'smiley') {
        return 'Smiley'
      }

      return 'ImageToggle'
    },
    addValue(val) {
      if (this.multiple) {
        if (Array.isArray(this.value)) {
          this.value = this.value.concat(val)
        } else {
          this.value = [val]
        }
      } else {
        this.value = val
      }
    },
    removeValue(val) {
      if (Array.isArray(this.value)) {
        this.value = removeValFromArr(this.value, val)
      } else {
        this.value = undefined
      }
    },
    deSelectAll(val) {
      for (let i = 0; i < this.options.length; i++) {
        const option = this.options[i]
        const optionRef = `option_${i}`

        if (option.value !== val) {
          // There's got to be a better way than using refs
          this.$refs[optionRef][0].inactivate()
        }
      }

      this.value = val
    },
    addCustomOption() {
      if (this.customOption.trim() == '') {
        alert('You must specify a description.')
        return false
      }
      const lastEl = this.options[this.options.length - 1]
      const obj = {
        key: this.name,
        value: `custom:${this.customOption}`,
      }

      if (lastEl && obj.value !== '') {
        const copyEl = { ...lastEl, isSelected: true }

        copyEl.value = obj.value
        copyEl.label = this.customOption
        copyEl.imageSrc = '/custom.svg'

        this.options.push(copyEl)
        this.$store.commit('user/add', obj)
        this.customOption = ''
      }
    },
  },
}
</script>

<style lang="scss">
.selector-custom-input {
  margin: 30px 0;
}

.round-button {
  background-color: $red;
  padding: 10px 18px;
  border-radius: 25px;
  color: $white;
  border: none;
  margin: 10px;
}

button:disabled {
  opacity: 0.4;
}
</style>
