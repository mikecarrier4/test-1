export default {
  props: {
    label: {
      type: String,
      default: '',
    },
    imageSrc: {
      type: String,
      default: '',
    },
    value: {
      type: [String, Boolean],
      default: '',
    },
    backgroundColor: {
      type: String,
      default: '#fff',
    },
    borderColor: {
      type: String,
      default: 'red',
    },
    color: {
      type: String,
      default: '#fff',
    },
    isSelected: {
      type: Boolean,
      default: false,
    },
    description: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      isActive: this.isSelected,
      status: 'neutral',
    }
  },
  methods: {
    inactivate() {
      this.isActive = false
      this.status = 'inactive'
    },
    toggleAndSendValue() {
      this.toggleSelected()
      this.sendValue()
    },
    toggleSelected() {
      this.isActive = !this.isActive
    },
    deSelectAllAndSendValue() {
      this.isActive = true
      this.status = 'active'
      this.$emit('deSelectAll', this.value)
    },
    sendValue() {
      if (this.isActive) {
        this.$emit('addValue', this.value)
      } else {
        this.$emit('removeValue', this.value)
      }
    }
  },
}
