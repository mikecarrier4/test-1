<template>
  <div
    :class="['pill', { active: isActive }]"
    :style="{ 
      borderColor: borderColor,
      backgroundColor: borderColor,
      color: borderColor
    }"
    @click="deSelectAllAndSendValue"
  >
    <span class="pill__text">{{ label }}</span>
  </div>
</template>

<script>
import SelectorOption from '../SelectorOption.js'

export default {
  extends: SelectorOption,
}
</script>

<style lang="scss">
.pill {
  margin: 20px auto;
  padding: 20px 40px;
  max-width: 280px;
  border-radius: 35px;
  border-width: 3px;
  border-style: solid;
  cursor: pointer;
  display: table;
  width: 280px;

  &.active {
    color: #fff !important;
  }

  &__text {
    font-weight: bold;
    font-size: 1.3rem;
    height: 1.3rem;
    line-height: 1.3rem;
    margin: 0;
    padding: 0;
    display: table-cell;
    vertical-align: middle;
  }
}

.pill:not(.active) {
  background-color: #fff !important;
}
</style>
