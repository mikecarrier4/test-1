<template>
  <div :class="['smiley', status]">
    <p :class="['smiley__description', status]">
      {{ description }}
    </p>
    <div class="smiley__button" @click="deSelectAllAndSendValue">
      <div
        :style="{ backgroundImage: `url(${imageSrc})` }"
        class="smiley__img"
      />
      <span class="smiley__label">{{ label }}</span>
    </div>
  </div>
</template>

<script>
import SelectorOption from '../SelectorOption.js'

export default {
  extends: SelectorOption,
}
</script>

<style lang="scss">
.smiley {
  display: inline-block;
  margin: 0 15px 15px 15px;
  vertical-align: top;

  &.inactive {
    opacity: 0.4;
  }

  &__button {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 80px;
    height: 80px;
    cursor: pointer;
    border-radius: 40px;
    background-color: $white;
    border: 3px solid $teal;
  }

  &__label {
    font-size: 1.3rem;
    color: $teal;
    font-weight: bold;
    text-align: center;
    line-height: 1;
  }

  &__img {
    display: none;
    height: 90%;
    width: 90%;
    background-repeat: no-repeat;
    background-position: center center;
    background-size: contain;
  }

  &__description {
    color: transparent;
    font-size: 1rem;
    line-height: 1;
    margin: 5px auto;
    text-align: center;
    padding: 0;
  }

  &.active {
    .smiley__button {
      background-color: $teal;
    }

    .smiley__img {
      display: block;
    }

    .smiley__label {
      display: none;
      opacity: 1;
    }

    .smiley__description {
      color: #4fc5d5;
    }
  }
}
</style>
