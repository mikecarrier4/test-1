<template>
  <div class="image-toggle-container">
    <div
      :class="['image-toggle', { active: isActive }]"
      @click="toggleAndSendValue"
    >
      <img class="image-toggle__icon" :src="imageSrc"></img>
      <span class="image-toggle__label">{{ label }}</span>
    </div>
  </div>
</template>

<script>
import SelectorOption from '../SelectorOption.js'

export default {
  extends: SelectorOption,
}
</script>

<style lang="scss">
.image-toggle-container {
  display: inline-block;
  height: 160px;
  width: 160px;
  padding: 2%;
  position: relative;
}

.image-toggle {
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  padding: 20px 10px;
  border: 2px solid $gray;
  height: 100%;
  width: 100%;
  vertical-align: top;
  cursor: pointer;
  border-radius: 10px;
  color: $black;

  &.active {
    border-color: $teal;
    -webkit-box-shadow: 0px 6px 3px 0px rgba(37,32,79,0.2);
    box-shadow: 0px 6px 3px 0px rgba(37,32,79,0.2);
  }

  &__icon {
    height: 35px;
    width: auto;
    display: block;
    margin: 0 auto;
  }

  &__label {
    display: block;
    line-height: 1.1;
    text-align: center;
    font-size: 0.9rem;
  }
}
</style>
