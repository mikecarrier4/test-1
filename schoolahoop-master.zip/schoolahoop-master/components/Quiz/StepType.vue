<script>
import ElementsRenderer from './ElementsRenderer'

export default {
  components: { ElementsRenderer },
  data() {
    return {
      title: '',
      elements: [],
    }
  },
  computed: {
    renderTitle() {
      const regex = /##([a-zA-Z]+)##/g

      return this.title.replace(regex, (match, p1) => {
        return this.$store.getters['user/fields'](p1)
      })
    },
  },
  methods: {
    userName() {
      return this.$store.getters['user/fields']('name')
    },
  },
}
</script>

<style>
</style>
