<template>
  <div :class="['quiz__step', { active: isActive }]">
    <slot />
    <div class="quiz__controls">
      <btn
        v-if="index !== 0"
        class="previous-button button button--outline red"
        :label="buttonLabel('Back')"
        @clicked="previousStep"
      />
      <btn
        class="next-button button"
        :label="buttonLabel('Next')"
        :disabled="hasErrors"
        @clicked="nextStep"
      />
    </div>
  </div>
</template>

<script>
import validate from 'validate.js'
import Btn from '../Btn'

export default {
  components: { Btn },
  props: {
    isActive: {
      type: Boolean,
      default: false,
    },
    requirements: {
      type: Object,
      default: () => {},
    },
    buttons: {
      type: Object,
      default: () => {},
    },
    index: {
      type: Number,
      default: 0,
    },
    name: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      errors: {},
    }
  },
  computed: {
    hasErrors() {
      return !this.isValid()
    },
    formatErrors() {
      let str = ''

      for (const key in this.errors) {
        const errorsArr = this.errors[key]
        const length = errorsArr.length

        for (let i = 0; i < length; i++) {
          str += errorsArr[i]

          if (i + 1 < length) {
            str += ', '
          }
        }
      }

      return str
    },
  },
  watch: {
    isActive(newVal) {
      if (newVal) {
        this.track()
      }
    },
  },
  mounted() {
    if (this.isActive) {
      this.track()
    }
  },
  methods: {
    track() {
      this.$mixpanel.track('Quiz step viewed', {
        step: this.name,
      })
    },
    buttonLabel(type) {
      if (this.buttons && this.buttons[type]) {
        return this.buttons[type]
      }

      return type
    },
    isValid() {
      const errors = validate(this.$store.state.user.fields, this.requirements)

      if (errors) {
        this.errors = errors
        return false
      }

      this.errors = {}
      return true
    },
    nextStep() {
      if (this.isValid()) {
        this.$emit('nextStep')
      }
    },
    previousStep() {
      this.$emit('previousStep')
    },
  },
}
</script>

<style lang="scss">
.quiz {
  &__step {
    display: none;

    &.active {
      display: block;
    }
  }

  &__errors {
    color: $red;
    font-size: 1rem;
    line-height: 1;
    margin: 10px 0;
    padding: 0;
  }

  &__controls {
    margin: 60px 0 10px;
  }
}
</style>
