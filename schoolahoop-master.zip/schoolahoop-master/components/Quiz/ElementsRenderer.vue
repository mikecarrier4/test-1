<template>
  <div>
    <component
      :is="componentType(element.type)"
      v-for="(element, index) in elements"
      :key="index"
      :placeholder="element.placeholder"
      :name="element.name"
      :loaded_value="element.loaded_value"
      :is-active="element.defaultValue"
      :label="element.label"
      :src="element.imageSrc"
      :options="element.options"
      :multiple="element.multiple"
      :num-options-per-row="element.numOptionsPerRow"
      :text="element.text"
      :description="element.description"
      :allow-custom-input="element.allowCustomInput"
    />
  </div>
</template>

<script>
import TextInput from './Element/TextInput'
import Selector from './Element/Selector'
import Date from './Element/Date'
import Paragraph from './Element/Paragraph'
import Slider from './Element/Slider'
import GoogleAutocomplete from './Element/GoogleAutocomplete'

export default {
  components: { TextInput, Selector, Date, Paragraph, Slider, GoogleAutocomplete },
  props: {
    elements: {
      type: Array,
      default: () => [],
    },
  },
  methods: {
    componentType(type) {
      if (type === 'textInput') {
        return 'TextInput'
      } else if (type === 'selector') {
        return 'Selector'
      } else if (type === 'date') {
        return 'Date'
      } else if (type === 'paragraph') {
        return 'Paragraph'
      } else if (type === 'slider') {
        return 'Slider'
      } else if (type === 'google_autocomplete') {
        return 'GoogleAutocomplete'
      }

      return 'TextInput'
    },
  },
}
</script>
