<template>
  <div class="school" :data-id="id">
    <div
      :style="{ backgroundImage: `url('${imageUrl}')` }"
      class="school__header-image"
      @click="toggleSchoolSelect"
    >
      <input
        v-model="isSelected"
        class="school__checkbox"
        type="checkbox"
      >
      <h2 class="school__name">
        {{ name }}
      </h2>
    </div>
    <div class="school__tags">
      <span
        v-for="tag in tags"
        :key="tag"
        class="school__tag"
      >
        {{ tag }}
      </span>
    </div>
    <div class="school__meta">
      <div class="school__meta__item">
        <img src="/alarm.svg">
        <span>
          {{ startTime }} - {{ endTime }}
        </span>
      </div>
      <div class="school__meta__item">
        <img src="/car.svg">
        <span>
          {{ getTravelTime() }} minutes
        </span>
      </div>
    </div>
    <application-period :status="applicationPeriod" />
    <Btn
      v-if="!showMoreInfo"
      label="+ More info"
      class="button button--outline teal button--block button--small mt-4 mb-4"
      @clicked="openInfo"
    />
    <template v-else>
      <h3 class="school__category__label">
        Address
      </h3>
      <p class="school__category__description">
        {{ address }}
      </p>
      <div v-if="missionStatement">
        <h3 class="school__category__label">
          Mission Statement
        </h3>
        <p class="school__category__description">
          {{ missionStatement }}
        </p>
      </div>
      <div v-if="studentTeacherRatio">
        <h3 class="school__category__label">
          Student / Teacher Ratio
        </h3>
        <student-teacher-ratio :ratio="studentTeacherRatio" />
      </div>
      <h3 class="school__category__label">
        School Information
      </h3>
      <div class="school__info-boxes">
        <info-box
          v-for="info in schoolInfo"
          :key="info"
          :label="info"
        />
      </div>
      <div class="school__info-boxes">
        <info-box
          v-if="ethnicities && isDiverse"
          :is-active="infoBox.diversity"
          :label="'Diverse'"
          :label-icon-src="'/check.svg'"
          :toggle-able="true"
          :img-src="'/diversity.svg'"
          @toggle="toggleInfoBox('diversity')"
        />
        <info-box
          v-if="ethnicities && !isDiverse"
          :is-active="infoBox.diversity"
          :label="'Not Diverse'"
          :label-icon-src="'/x.svg'"
          :toggle-able="true"
          :img-src="'/diversity.svg'"
          @toggle="toggleInfoBox('diversity')"
        />
        <info-box
          v-if="coed"
          :is-active="infoBox.coed"
          :label="'Co-ed'"
          :toggle-able="true"
          :img-src="'/coed.svg'"
          @toggle="toggleInfoBox('coed')"
        />
      </div>
      <div class="info-box__reveal">
        <diversity
          v-if="ethnicities && infoBox.diversity"
          :ethnicities="ethnicities"
          :is-diverse="isDiverse"
        />
        <template v-if="infoBox.coed">
          <pill
            v-if="coed"
            :primary="{label: 'Boys', color: '#4FC5D5', value: coed.male_students }"
            :secondary="{label: 'Girls', color: '#FFAE94', value: coed.female_students }"
          />
        </template>
      </div>
      <Btn
        label="- Hide info"
        class="button button--teal button--block button--small mt-4 mb-4"
        @clicked="hideInfo"
      />
    </template>
  </div>
</template>

<script>
import Btn from './Btn'
import StudentTeacherRatio from './School/StudentTeacherRatio'
import InfoBox from './School/InfoBox'
import Diversity from './School/Diversity'
import ApplicationPeriod from './School/ApplicationPeriod'
import Pill from './Chart/Pill'

export default {
  components: {
    Btn,
    StudentTeacherRatio,
    InfoBox,
    Diversity,
    ApplicationPeriod,
    Pill,
  },
  props: {
    name: {
      type: String,
      default: '',
    },
    id: {
      type: String,
      default: '',
    },
    tags: {
      type: Array,
      default: () => [],
    },
    hours: {
      type: String,
      default: '',
    },
    distance: {
      type: Number
    },
    address: {
      type: String,
      default: '',
    },
    missionStatement: {
      type: String,
      default: '',
    },
    applicationPeriod: {
      type: String,
      default: '',
    },
    imageUrl: {
      type: String,
      default: 'https://storage.googleapis.com/schoolahoop-assets/pearl%402x.jpg',
    },
    studentTeacherRatio: {
      type: Number,
    },
    ethnicities: {
      type: Object,
      default: () => {},
    },
    coed: {
      type: Object,
      default: () => {},
    },
    travelTime: {
      type: Object,
      default: () => {},
    },
    startTime: {
      type: String,
      default: '',
    },
    endTime: {
      type: String,
      default: '',
    },
    schoolInfo: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      showMoreInfo: false,
      isSelected: this.isSchoolSelected(),
      infoBox: {
        diversity: true,
        coed: false,
      },
    }
  },
  computed: {
    isDiverse() {
      if (!this.ethnicities) {
        return false;
      }

      const countsOfStudentsByEthnicity = Object.keys(this.ethnicities)
        .map(key => this.ethnicities[key])
        .filter(count => Number.isInteger(count));

      const mostRepresentedRatio = 
        Math.max(...countsOfStudentsByEthnicity) / countsOfStudentsByEthnicity.reduce((total, count) => total + count, 0);
      
      return mostRepresentedRatio < 0.8;
    },
  },
  watch: {
    isSelected(newVal) {
      if (newVal) {
        this.addSchool()
      } else {
        this.removeSchool()
      }
    },
  },
  methods: {
    getTravelTime() {
      const tt = this.travelTime

      if (tt.driving) {
        return parseInt(tt.driving.time)
      } else {
        for (const k in tt) {
          return parseInt(tt[k].time)
        }
      }
    },
    openInfo() {
      this.showMoreInfo = true
    },
    hideInfo() {
      this.showMoreInfo = false
    },
    toggleInfoBox(type) {
      const oldVal = this.infoBox[type]

      this.closeInfoBoxes()

      if (!oldVal) {
        this.infoBox[type] = true
      }
    },
    closeInfoBoxes() {
      for (const key in this.infoBox) {
        this.infoBox[key] = false
      }
    },
    removeSchool() {
      const obj = {
        key: 'chosen_school_ids',
        value: this.id,
      }

      this.$store.commit('user/removeFromArr', obj)
    },
    addSchool() {
      const obj = {
        key: 'chosen_school_ids',
        value: this.id,
      }

      this.$store.commit('user/add', obj)
    },
    toggleSchoolSelect() {
      this.isSelected = !this.isSelected
    },
    isSchoolSelected() {
      let chosen_school_ids = this.$store.getters['user/fields']('chosen_school_ids')
      let is_selected = false
      chosen_school_ids.forEach((school_id, index) => {
        if (school_id == this.id) {
          is_selected = true
        }
      })
      return is_selected
    },
  }
}
</script>

<style lang="scss">
.school {
  margin: 20px;
  display: inline-block;
  vertical-align: top;
  width: 100%;

  @media(min-width: 576px) {
    width: 340px;
  }

  &__name {
    color: $white;
    font-size: 1.5rem;
    font-weight: bold;
    position: absolute;
    background-color: rgba(0, 0, 0, 0.4);
    bottom: 0;
    left: 0;
    right: 0;
    padding: 10px 5px;
  }

  &__header-image {
    width: 100%;
    height: 180px;
    position: relative;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    background-color: $white;
    cursor: pointer;
  }

  &__checkbox {
    position: absolute;
    top: 25px;
    right: 25px;
    -ms-transform: scale(2.5); /* IE */
    -moz-transform: scale(2.5); /* FF */
    -webkit-transform: scale(2.5); /* Safari and Chrome */
    -o-transform: scale(2.5); /* Opera */
    transform: scale(2.5);
  }

  &__tag {
    background-color: $teal;
    color: $white;
    font-size: 0.8rem;
    padding: 3px 8px;
    margin: 8px 3px 8px 0;
    border-radius: 20px;
    display: inline-block;
    font-weight: bold;
  }

  &__meta {
    &__item {
      color: $grayPurple;
      display: inline-flex;
      margin: 10px 18px 10px 0;
      align-items: center;
      line-height: 1;

      img {
        margin-right: 10px;
        height: 18px;
      }
    }
  }

  &__info-boxes {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }

  &__category {
    &__label {
      color: $teal;
      margin: 25px 0 2px;
      font-size: 1rem;
      font-weight: bold;
    }

    &__description {
      margin: 0;
      opacity: 1;
    }
  }

  button {
    margin-left: auto;
    margin-right: auto;
    display: block;
  }
}

.info-box {
  &__reveal {
    margin: 20px 0;
  }
}
</style>
