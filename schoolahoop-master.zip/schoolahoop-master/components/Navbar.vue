<template>
  <div>
    <b-navbar id="topnav" toggleable="md" type="light">
      <div class="container">
        <b-navbar-brand href="/">
          <img id="desktop-logo" src="/logo.svg" alt="Fun, playful Schoolahoop school finder logo">
          <img id="mobile-logo" src="/o-logo.svg" alt="Fun, playful Schoolahoop school finder logo">
        </b-navbar-brand>

        <b-navbar-toggle target="nav-collapse" />

        <b-collapse id="nav-collapse" is-nav>
          <b-navbar-nav class="ml-auto">
            <b-nav-item href="/faq">
              About &amp; FAQs
            </b-nav-item>
            <b-nav-item href="mailto:contact@schoolahoop.org">
              Contact Us
            </b-nav-item>
            <b-nav-item href="/faq?lang=es#es-lang">
              Espa&#241;ol
            </b-nav-item>
          </b-navbar-nav>
        </b-collapse>
      </div>
    </b-navbar>
  </div>
</template>

<script>
  export default {
    data () {
      return {
        showNavbar: true,
        lastScrollPosition: 0,
        timeOutSet: false,
        timer: false,
      }
    },
    mounted () {
      window.addEventListener('scroll', this.onScroll)
      this.onScroll()
    },beforeDestroy () {
      window.removeEventListener('scroll', this.onScroll)
    },
    methods: {
      onScroll () {
        const currentScrollPosition = window.pageYOffset || document.documentElement.scrollTop
        
        if (navbar == undefined) {
          var navbar = document.getElementById("topnav")
        }
        navbar.classList.remove("navbar--hidden")

        if (currentScrollPosition < 70) {
          if (wrapper == undefined) {
            var wrapper = document.getElementsByClassName("wrapper")[0]
          }
          wrapper.classList.remove("navbar--hidden")
        }

        if (this.timer !== false) {
          clearTimeout(this.timer)
        }
        
        this.timer = setTimeout(function(){
          if (navbar == undefined) {
            navbar = document.getElementById("topnav")
          }
          if (body == undefined) {
            var body = document.getElementsByTagName("BODY")[0]
          }

          if (navbar_collapse == undefined) {
            var navbar_collapse = document.getElementById("topnav").getElementsByClassName("navbar-collapse")[0]
          }

          if ((currentScrollPosition > 100 || body.classList.contains('quiz-body')) && !navbar_collapse.classList.contains('show')) {
            navbar.classList.add("navbar--hidden")
            if (currentScrollPosition < 70) {
              if (wrapper == undefined) {
                var wrapper = document.getElementsByClassName("wrapper")[0]
              }
              wrapper.classList.add("navbar--hidden")
            }
          }
        }, 3000)
        this.lastScrollPosition = currentScrollPosition
      },
    },
  }
</script>

<style lang="scss">
.quiz-body {
  .navbar {
    @media(max-width: 600px) {
      background-color: $white;
    }
  }
}
.navbar {
  padding-top: 10px;
  padding-bottom: 10px;
  transform: translate3d(0, 0, 0);
  transition: 0.1s all ease-out;
  width: 100vw;

  @media(max-width: 600px) {
    position: fixed;
    background-color: $beige;
    z-index: 10;
  }

  &-brand {
    img {
      height: 40px;
    }
  }

  .nav-link {
    padding-left: 20px !important;
    padding-right: 20px !important;
    font-weight: bold;
    color: $teal !important;
    font-size: 1.2rem;
  }
}

.navbar.navbar--hidden {
  @media(max-width: 600px) {
    transform: translate3d(0, -100%, 0);
  }
}

.supernav {
  text-align: right;
  padding: 10px 0 0 0;

  a {
    color: $red;
    padding: 0 20px;
  }
}

@media(max-width: 600px) {
  .wrapper:not(.navbar--hidden) {
    padding-top: 70px;
  }
}

#mobile-logo {
  display: none;
  @media(max-width: 600px) {
    display: inline-block;
  }
}

@media(max-width: 600px) {
  #desktop-logo {
    display: none;
  }
}
</style>
