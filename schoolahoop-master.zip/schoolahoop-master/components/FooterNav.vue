<template>
  <div class="footer">
    <div class="footer-top">
      <div class="social-links">
        <a class="facebook" href="https://www.facebook.com/schoolahoopla/" target="_blank">
          <img src="/facebook.svg">
        </a>
        <a class="instagram" href="https://www.instagram.com/goschoolahoop/" target="_blank">
          <img src="/instagram.svg">
        </a>
        <a class="twitter" href="https://twitter.com/GoSchoolahoop" target="_blank">
          <img src="/twitter.svg">
        </a>
      </div>
      <div class="footer-links">
        <a class="footer-link" href="/privacy">
          Privacy Policy
        </a>
        <a class="footer-link" href="/tos">
          Terms of Service
        </a>
      </div>
      <div class="clearboth"></div>
    </div>
    <div class="footer-copyright">
      <strong>&copy; Copyright 2020</strong> All rights reserved.
    </div>
  </div>
</template>

<style lang="scss">
.clearboth {
  clear: both;
}

.footer {
  padding: 40px 18px 0;
  text-align: center;

  @media(max-width: 576px) {
    padding-left: 0;
    padding-right: 0;
  }

  a {
    color: $teal;
    margin: 0 20px;
    font-weight: bold;
  }

  .footer-top {
    padding-bottom: 30px;

    @media(max-width: 576px) {
      padding-bottom: 20px;
    }
  }

  .social-links {
    margin-left: 20px;
    text-align: left;

    @media(min-width: 577px) {
      float: left;
    }

    @media(max-width: 576px) {
      margin-bottom: 20px;
    }

    a {
      margin: 0;
    }

    img {
      width: 35px;
      margin-right: 14px;

      @media(max-width: 576px) {
        margin-right: 28px;
      }
    }
  }

  .footer-links {
    text-align: left;

    @media(min-width: 577px) {
      float: right;
      position: relative;
      top: 3px;
    }

    a {
      @media(max-width: 576px) {
        display: block;
        margin-bottom: 20px;
      }
    }
  }

  .footer-copyright {
    border-top: 2px solid #4fc5d5;
    clear: both;
    text-align: left;
    padding: 30px 20px 20px;
    color: #a4a3b6;

    @media(max-width: 576px) {
      padding-top: 20px;
    }
    
    strong {
      color: #25204f;
    }
  }
}
</style>
