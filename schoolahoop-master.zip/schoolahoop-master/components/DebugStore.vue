<template>
  <table class="table table-sm table-bordered table-striped mt-4">
    <tbody>
      <tr v-for="(value, name) in obj" :key="name">
        <td>{{ name }}</td>
        <td>{{ value }}</td>
      </tr>
    </tbody>
  </table>
</template>

<script>
export default {
  props: {
    obj: {
      type: Object,
      default: () => {},
    },
  },
}
</script>
