<template>
  <div
    :class="['info-box', { active: isActive, toggleable: toggleAble }]"
    @click="clickHandler"
  >
    <img v-if="imgSrc" class="info-box__img" :src="imgSrc">
    <div class="info-box__label">
      {{ label }}
      <img v-if="labelIconSrc" class="info-box__icon" :src="labelIconSrc">
    </div>
    <span
      v-if="toggleAble"
      class="info-box__view"
    >
      {{ viewLabel }}
    </span>
  </div>
</template>

<script>
export default {
  props: {
    isActive: {
      type: Boolean,
      default: false,
    },
    label: {
      type: String,
      default: '',
    },
    labelIconSrc: {
      type: String,
      default: '',
    },
    toggleAble: {
      type: Boolean,
      default: false,
    },
    imgSrc: {
      type: String,
      default: '',
    },
  },
  computed: {
    viewLabel() {
      if (this.isActive) {
        return 'Hide'
      }

      return 'View'
    },
  },
  methods: {
    clickHandler() {
      this.$emit('toggle')
    },
  },
}
</script>

<style lang="scss">
.info-box {
  padding: 15px;
  border: 1px solid $teal;
  width: 95px;
  margin: 10px 10px 10px 0;
  border-radius: 10px;
  background-color: $white;
  display: flex;
  justify-content: center;
  flex-direction: column;

  &.toggleable {
    width: 150px;
    border: 2px solid $gray;
    cursor: pointer;
  }

  &.active {
    border-color: $teal;
    -webkit-box-shadow: 0px 6px 3px 0px rgba(37,32,79,0.2);
    box-shadow: 0px 6px 3px 0px rgba(37,32,79,0.2);
  }

  &__img {
    margin: 10px auto;
    display: block;
    height: 40px;
  }

  &__label {
    text-align: center;
    color: $black;
    display: block;
    margin: 3px 0;
    line-height: 1;
  }

  &__view {
    text-align: center;
    display: block;
    margin: 3px 0;
    color: $teal;
    line-height: 1;
    font-size: 0.9rem;
  }
}
</style>
