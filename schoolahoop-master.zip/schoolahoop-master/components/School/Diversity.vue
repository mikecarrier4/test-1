<template>
  <div class="diversity">
    <h4>How do we determine this?</h4>
    <p v-if="isDiverse">We consider a school diverse if not more than 80% of one racial group is present.</p>
    <p v-else>We consider a school to not be diverse if one racial group makes up over 80% of the population.</p>
    <doughnut
      v-if="dataLoaded"
      :data="data"
      :options="options"
    />
  </div>
</template>

<script>
import Doughnut from '../Chart/Doughnut.js'

export default {
  components: { Doughnut },
  props: {
    ethnicities: {
      type: Object,
      default: () => {},
    },
    isDiverse: {
      type: Boolean,
      default: true,
    }
  },
  data() {
    return {
      dataLoaded: false,
      data: {
        datasets: [
          {
            data: [],
            backgroundColor: [
              '#25204F',
              '#4FC5D5',
              '#FFAE94',
              '#FAD100',
              '#EE7552',
              '#A594F0',
            ],
            hoverBackgroundColor: [
              '#25204F',
              '#4FC5D5',
              '#FFAE94',
              '#FAD100',
              '#EE7552',
              '#A594F0',
            ],
          },
        ],
        labels: [],
      },
      options: {
        responsive: true,
        legend: {
          position: 'right',
        },
      },
    }
  },
  mounted() {
    this.initializeData()
    this.dataLoaded = true
  },
  methods: {
    generateColor() {
      return `hsl(${360 * Math.random()}, 100%, 80%)`
    },
    initializeData() {
      for (const key in this.ethnicities) {
        const name = key
        const value = this.ethnicities[key]
        const dataset = this.data.datasets[0]
        // const color = this.generateColor()

        dataset.data.push(value)
        // dataset.backgroundColor.push(color)
        // dataset.hoverBackgroundColor.push(color)

        this.data.labels.push(name)
      }
    }
  },
}
</script>

<style lang="scss">
.diversity {
  h4 {
    font-weight: bold;
    font-size: 1rem;
    line-height: 1;
    margin: 5px 0;
  }

  p {
  margin: 5px 0;
  line-height: 1.2;
  }
}
</style>
