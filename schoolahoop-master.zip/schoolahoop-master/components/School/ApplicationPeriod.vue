<template>
  <div>
    <p v-if="status" :class="['application-period', textColor()]">
      <strong>Application Period:</strong> {{ status }}
    </p>
    <p v-else :class="['application-period', 'd-none', 'd-sm-block', textColor()]">
      <strong>&nbsp;</strong>
    </p>
  </div>
</template>

<script>
export default {
  props: {
    status: {
      type: String,
      default: ''
    },
  },
  methods: {
    textColor() {
      const status = this.status

      if (status === 'Open') {
        return 'teal'
      }

      if (status === 'About to close' || status === 'Closed') {
        return 'red'
      }

      return 'black'
    },
  },
}
</script>

<style lang="scss">
.application-period {
  color: $black;
  opacity: 1;
  margin: 10px 0;
  line-height: 1;
  display: none;

  &.teal, &.red, &.black {
    display: block;
  }

  &.teal {
    color: $teal;
  }

  &.red {
    color: $red;
  }

  &.black {
    color: $black;
  }
}
</style>
