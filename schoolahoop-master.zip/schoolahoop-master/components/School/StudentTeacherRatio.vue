<template>
  <div class="student-teacher">
    <div class="student-teacher__diagram">
      <img class="student-teacher__teacher" src="/teacher.svg">
      <div class="student-teacher__students">
        <img
          v-for="index in numStudents"
          :key="index"
          :src="`/${getRandomStudentImg()}`"
          class="student-teacher__student"
        >
      </div>
    </div>
    <span>{{ numStudents }}:1</span>
  </div>
</template>

<script>
const getRandomInt = (max) => {
  return Math.floor(Math.random() * Math.floor(max))
}

export default {
  props: {
    ratio: {
      type: Number,
    },
  },
  data() {
    return {
      numStudents: 0,
    }
  },
  mounted() {
    this.parseStudentNum()
  },
  methods: {
    parseStudentNum() {
      this.numStudents = parseInt(this.ratio)
    },
    getRandomStudentImg() {
      const int = getRandomInt(4) + 1
      return `student${int}.svg`
    },
  },
}
</script>

<style lang="scss">
.student-teacher {
  margin: 10px 0;

  span {
    text-align: center;
    color: $grayPurple;
    display: block;
    margin: 10px 0;
    opacity: 0.5;
  }

  &__diagram {
    display: flex;
    align-items: flex-end;
  }

  &__teacher {
    height: 60px;
  }

  &__student {
    height: 38px;
    margin: 5px 5px 0 5px;
  }
}
</style>
