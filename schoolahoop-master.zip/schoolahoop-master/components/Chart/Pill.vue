<template>
  <div
    :style="{ backgroundColor: secondary.color }"
    class="pill-chart"
  >
    <div class="pill-chart__secondary-content">
      <div>
        {{ secondary.label }} {{ secondaryPercent }}%
      </div>
    </div>
    <div
      :style="{ backgroundColor: primary.color, width: percentToString(primaryPercent) }"
      class="pill-chart__primary-content"
    >
      <div>
        {{ primaryPercent }}% {{ primary.label }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    primary: {
      type: Object,
      default: () => {},
    },
    secondary: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      primaryPercent: 50,
      secondaryPercent: 50,
    }
  },
  mounted() {
    this.calculatePercentages()
  },
  methods: {
    percentToString(val) {
      return val + '%'
    },
    calculatePercentages() {
      const total = this.primary.value + this.secondary.value

      this.primaryPercent = parseInt((this.primary.value / total) * 100)
      this.secondaryPercent = 100 - this.primaryPercent
    },
  },
}
</script>

<style lang="scss">
.pill-chart {
  position: relative;
  border-radius: 40px;
  max-width: 250px;
  margin: 20px auto;

  &__primary-content {
    position: absolute;
    z-index: 1;
    top: 0;
    bottom: 0;
    left: 0;
    border-bottom-left-radius: 40px;
    border-top-left-radius: 40px;
    display: flex;
    align-items: center;
    padding-left: 30px;
  }

  &__secondary-content {
    padding: 30px;
    display: flex;
    justify-content: flex-end;
  }

  &__primary-content, &__secondary-content {
    color: $white;
    line-height: 1.1;
  }
}
</style>
