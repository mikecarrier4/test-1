<template>
  <div class="quiz">
    <loading
      v-if="isLoading"
      :screen-time="2600"
      @finishedLoadingLoop="loadingLoopFinished"
    />
    <QuizStep
      v-for="(step, index) in steps"
      v-else
      :key="index"
      :is-active="index === currentStepIndex"
      :requirements="step.requirements"
      :buttons="step.buttons"
      :index="index"
      :name="step.type"
      @nextStep="nextStep"
      @previousStep="previousStep"
    >
      <component :is="step.type" />
    </QuizStep>

    <b-modal 
      v-bind:hide-footer="true" 
      v-bind:hide-header="true" 
      ref="dontleave-modal" 
      id="dontleave-modal"
    >
      <img id="dontleave_close" src="x.png">
      <h1>Are you sure you want to<br><span class="color-teal">leave the quiz?</span></h1>
      <p>You may lose your progress.</p>
      <a href="/" class="button button--outline red leave-quiz" id="dontleave_button">Leave Quiz</a>
      <a href="#" class="button" id="dontleave_cancel">Cancel</a>
    </b-modal>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import Loading from '~/components/Quiz/Loading'
import QuizStep from '~/components/Quiz/Step'
import NameStep from '~/components/Quiz/StepType/Name'
import GradeStep from '~/components/Quiz/StepType/Grade'
import PreferencesStep from '~/components/Quiz/StepType/Preferences'
import TransportationStep from '~/components/Quiz/StepType/Transportation'
import HomeAddressStep from '~/components/Quiz/StepType/HomeAddress'
import SchoolsAlongCommuteStep from '~/components/Quiz/StepType/SchoolsAlongCommute'
import WorkAddressStep from '~/components/Quiz/StepType/WorkAddress'
import SchoolTimeStep from '~/components/Quiz/StepType/SchoolTime'
import CommuteStep from '~/components/Quiz/StepType/Commute'

export default {
  components: {
    Loading,
    QuizStep,
    NameStep,
    GradeStep,
    PreferencesStep,
    TransportationStep,
    HomeAddressStep,
    SchoolsAlongCommuteStep,
    WorkAddressStep,
    SchoolTimeStep,
    CommuteStep,
  },
  data() {
    return {
      currentStepIndex: 0,
      steps: [
        {
          type: 'NameStep',
          requirements: {
            name: {
              presence: { allowEmpty: false },
            },
          },
          buttons: {
            Next: 'Nice To Meet You!',
          },
        },
        {
          type: 'GradeStep',
          requirements: {
            grade: {
              presence: { allowEmpty: false },
            }
          },
        },
        {
          type: 'PreferencesStep',
          requirements: {
            preferences: {
              presence: { allowEmpty: false },
            },
          },
        },
        {
          type: 'TransportationStep',
          requirements: {
            transportation: {
              presence: { allowEmpty: false },
            },
          },
        },
        {
          type: 'HomeAddressStep',
          requirements: {
            home_address: {
              presence: { allowEmpty: false },
            },
          },
        },
        {
          type: 'SchoolsAlongCommuteStep',
          requirements: {
            consider_commute: {
              presence: { allowEmpty: false },
            },
          },
        },
        {
          type: 'WorkAddressStep',
          skip: {
            consider_commute: false,
          },
          requirements: {
            work_address: {
              presence: { allowEmpty: false },
            },
          },
        },
        {
          type: 'SchoolTimeStep',
          skip: {
            consider_commute: true,
          },
          requirements: {
            max_travel_time: {
              presence: { allowEmpty: false },
            },
          },
        },
        {
          type: 'CommuteStep',
          skip: {
            consider_commute: false,
          },
          requirements: {
            max_travel_time: {
              presence: { allowEmpty: false },
            },
          },
        },
      ],
      loadingScreensLooped: false,
      isLoading: false,
      dataLoaded: false,
      dataError: false,
    }
  },
  computed: {
    finishedProcessing() {
      if (this.$route.query.step != undefined) {
        let step_index = -1
        let requested_step = this.$route.query.step
        this.steps.forEach(function(step, index){
          if (step.type == requested_step) {
            step_index = index
          }
        })
        if (step_index != -1) {
          this.setStep(step_index)
        }
      }
      // return this.loadingScreensLooped
      return this.loadingScreensLooped && this.dataLoaded
    },
    ...mapState({
      fields: state => state.user.fields,
    }),
  },
  watch: {
    finishedProcessing(newVal) {
      if (newVal) {
        const routeObj = { name: 'results' }

        if (this.dataError) {
          routeObj.params = { error: true }
        }
        this.$mixpanel.track('Quiz completed', {
          error: this.dataError,
        })
        this.$router.push(routeObj)
      }
    },
  },
  mounted () {
    window.addEventListener('scroll', this.onScroll)
    var links = Array.from(document.getElementsByClassName('nav-link'))
    links.forEach((link, index) => {
      link.addEventListener('click',this.dontLeave)
    })
    var footer_links = Array.from(document.getElementsByClassName('footer-link'))
    footer_links.forEach((link, index) => {
      link.addEventListener('click',this.dontLeave)
    })

    document.getElementsByClassName('navbar-brand')[0].addEventListener('click', this.dontLeave)
    window.addEventListener('keydown', this.enterNext)
  },
  methods: {
    enterNext(event) {
      let next_button = document.getElementsByClassName('quiz__step active')[0].getElementsByClassName('next-button')[0]
      if (event.keyCode == 13 && !next_button.disabled) {
        this.nextStep()
      }
    },
    dontLeave(event) {

      var target_link = event.target.href

      if (target_link == undefined) {
        target_link = event.target.parentElement.href
      }

      event.preventDefault()
      event.stopPropagation()
      this.$refs['dontleave-modal'].show()

      setTimeout(() => {
        var leave_button = document.getElementById('dontleave_button').href = target_link

        var cancel_button = document.getElementById('dontleave_cancel')
        cancel_button.addEventListener('click', (event) => {
          event.preventDefault()
          event.stopPropagation()
          this.$refs['dontleave-modal'].hide()
        })
        var close_button = document.getElementById('dontleave_close')
        close_button.addEventListener('click', (event) => {
          event.preventDefault()
          event.stopPropagation()
          this.$refs['dontleave-modal'].hide()
        })
      },100)

      return false
    },
    isValidIndex(index) {
      if (this.steps[index]) {
        if (this.skipStep(index)) {
          return false
        }

        return true
      }

      return false
    },
    setStep(index) {
      this.currentStepIndex = index

      while (index >= 0 && index < this.steps.length) {
        if (this.isValidIndex(index)) {
          return index
        }

        index++
      }

      return this.currentStepIndex
    },
    changeIndex(delta) {
      window.localStorage.setItem('user_fields', JSON.stringify(this.$store.state.user.fields))
      
      let index = this.currentStepIndex + delta

      while (index >= 0 && index < this.steps.length) {
        if (this.isValidIndex(index)) {
          return index
        }

        index += delta
      }
      return this.currentStepIndex
    },
    nextStep() {
      const nextStepIndex = this.changeIndex(1)

      if (nextStepIndex === this.currentStepIndex) {
        this.submitData()
        return
      }
      this.currentStepIndex = nextStepIndex
    },
    previousStep() {
      this.currentStepIndex = this.changeIndex(-1)
    },
    skipStep(index) {
      const step = this.steps[index]
      const skip = step.skip

      if (skip) {
        for (const key in skip) {
          if (skip[key] === this.fields[key]) {
            return true
          }
        }
      }

      return false
    },
    submitData() {
      window.localStorage.setItem('user_fields', JSON.stringify(this.$store.state.user.fields))

      this.isLoading = true

      this.$store.dispatch('user/sendQuizData')
        .then(() => {

          var links = Array.from(document.getElementsByClassName('nav-link'))
          links.forEach((link, index) => {
            link.removeEventListener('click',this.dontLeave)
          })
          var footer_links = Array.from(document.getElementsByClassName('footer-link'))
          footer_links.forEach((link, index) => {
            link.removeEventListener('click',this.dontLeave)
          })
          document.getElementsByClassName('navbar-brand')[0].removeEventListener('click', this.dontLeave)
          
          this.dataLoaded = true
        })
        .catch(() => {
          this.dataError = true
          this.dataLoaded = true
        })
    },
    loadingLoopFinished() {
      this.loadingScreensLooped = true
    }
  },
  beforeCreate(){
    document.body.className = 'quiz-body';
    let user_fields = JSON.parse(window.localStorage.getItem('user_fields'))
    if (user_fields !== null && typeof user_fields === 'object') {
      let user_keys = Object.keys(user_fields)
      user_keys.forEach((key, index) => {
        const obj = {}
        obj.key = key
        obj.value = user_fields[key]

        this.$store.commit('user/update', obj)
      })
    }
  },
}
</script>

<style lang="scss">
body.quiz-body .footer {
  display: none;
}

@media(max-width: 600px) {
  body.quiz-body {
    background-color: $white;
  }
}

.quiz {
  padding: 10px;
  text-align: center;
  margin: auto;
  min-height: 650px;

  @media(min-width: 768px) {
    padding: 30px;
  }

  @media(max-width: 601px) {
    min-height: 0;
  }

  @media(min-width: 600px) {
    border-radius: 14px;
    background-color: $white;
    -webkit-box-shadow: 0px 8px 13px 8px rgba(37,32,79,0.18);
    box-shadow: 0px 8px 13px 8px rgba(37,32,79,0.18);
  }
}

#dontleave-modal {
  text-align: center;

  .button.leave-quiz {
    opacity: 0.5;
  }

  .button.leave-quiz:hover {
    color: #ee7552;
    opacity: 1;
  }

  #dontleave_cancel:hover {
    color: #fff;
  }

  #dontleave_close {
    width: 14px;
    position: absolute;
    right: 19px;
    top: 19px;
  }

  #dontleave_close:hover {
    cursor: pointer;
  }

  h1 {
    margin-bottom: 37px;
  }

  p {
    margin-bottom: 50px;
    font-family: Nunito;
    font-size: 18px;
    font-weight: normal;
    font-stretch: normal;
    font-style: normal;
    line-height: normal;
    letter-spacing: normal;
    text-align: center;
    color: #25204f;
    opacity: 1;
  }
}

#dontleave-modal .modal-body {
  padding-top: 60px;
  padding-bottom: 80px;
}

#dontleave-modal .modal-dialog {
  margin-top: 100px;
}
</style>
