<template>
  <button
    :disabled="disabled"
    @click="clicked"
  >
    {{ label }}
  </button>
</template>

<script>
export default {
  props: {
    label: {
      type: String,
      default: '',
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    clicked() {
      this.$emit('clicked')
    },
  },
}
</script>

<style lang="scss">
.button {
  background-color: $red;
  color: $white;
  border-radius: 25px;
  padding: 10px 30px;
  border: none;
  font-weight: bold;
  margin: 10px 5px;
  font-size: 1.1rem;

  &:disabled {
    opacity: 0.4;
  }

  &.button--teal {
    background-color: $teal;
  }

  &.button--outline {
    &.red {
      background-color: $white;
      border: 2px solid $red;
      color: $red;
    }
  }

  &.button--block {
    margin-left: auto;
    margin-right: auto;
    display: block;
  }

  &.button--inline-block {
    display: inline-block;
  }

  &.button--outline {
    &.teal {
      background-color: $white;
      border: 2px solid $teal;
      color: $teal;
    }
  }

  &.button--small {
    padding: 5px 20px;
  }
}
</style>
