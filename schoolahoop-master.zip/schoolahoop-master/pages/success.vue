<template>
  <div class="success-page text-center">
    <h1>
      You've <span class="color-teal">got mail</span>!
    </h1>
    <p class="mw-420 mr-auto ml-auto">
      Look out for an email from us.
    </p>
    <img class="mail-img" src="/mail.svg">
    <btn
      label="Back to Results"
      class="button button--block mt-40"
      @clicked="backToResults"
    />
  </div>
</template>

<script>
import Btn from '~/components/Btn'

export default {
  components: { Btn },
  methods: {
    backToResults() {
      this.$router.push({ name: 'results' })
    },
  },
  mounted() {
    this.$store.commit('viewConfig/hideFooterOnMobile')
  },
}
</script>

<style>
</style>
