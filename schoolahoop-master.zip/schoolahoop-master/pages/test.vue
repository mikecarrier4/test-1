<template>
  <div>
    <p>This is a test page!</p>
    <p>You can output data here like this: {{ foo }} </p>
  </div>
</template>

<script>
const axios = require('axios').default

export default {
  data() {
    return {
      foo: 'bar',
    }
  },
  mounted() {
    // Filter schools test
    // const formResultsTest2 = {
    //   name: 'Danny',
    //   grade: '2nd',
    //   preferences: [
    //     'top_20_safety',
    //     'top_20_score',
    //     'school_bus_available',
    //     'diversity',
    //     'non_religious',
    //     'religious',
    //     'no_spanking',
    //     'after_school_care',
    //     'special_needs_education',
    //     'gifted_student',
    //     'english_as_second_language',
    //     'k12_school',
    //     'school_library',
    //     'foreign_languages',
    //     'theater',
    //     'dance',
    //     'vegan_vegetarian',
    //     'visual_arts',
    //     'computer_science',
    //     'music',
    //     'sports',
    //     'healthy_lunch_options',
    //     'science',
    //     '<any other custom user string>'
    //   ],
    //   transportation: ['driving', 'walking'],
    //   home_address: '7213 Thames Trail Colleyville, TX',
    //   // work_address: '8840 Benbrook Blvd, Benbrook, TX 76126',
    //   max_travel_time: '20 min or less',
    //   commute_time: '20 min or less',
    // }

    const formResultsTest2 = {
      name: 'Test',
      grade: '3rd',
      preferences: [
        'sports',
      ],
      transportation: ['driving'],
      home_address: '629 Hillview Dr Hurst, TX',
      // work_address: '1955 lakeway drive, Lewisville, TX, USA',
      max_travel_time: '30 minutes',
      // commute_time: '20 min or less',
    }

    axios.post('/.netlify/functions/filter_schools', JSON.stringify({
      form_results: formResultsTest2
    })).then((results) => {
      console.log('filter_schools response: ', results)
      results.data.schools.forEach(function (school) {
        console.log('distance: ', school.distance)
        console.log('distance_lc: ', school.distance_lc)
        console.log('max_distance: ', school.max_distance)
        console.log('===============')
      })
      window.res = results
    }).catch((err) => {
      if (err.response.status >= 410 && err.response.status < 420) {
        console.log('Error has already been emailed: ', err)
      } else {
        console.log('Error has not been emailed.  Attempting now: ', err)
        axios.post('/.netlify/functions/email_error', {
          error: err
        }).then((data) => {
          data = data.data
          if (data.email_result === undefined || data.email_result === false) {
            console.log('Error sending email: ', data)
          } else {
            console.log('Error email was sent.')
          }
        }).catch((err) => {
          console.log('Error email could not be sent: ', err)
        })
      }
    })

    // Contact Schools Test
    // axios.post('/.netlify/functions/contact_schools', {
    //   email: 'jimmy@test.com',
    //   fullName: 'James McDougal',
    //   childName: 'Lucy',
    //   grade: 'K',
    //   travelMode: ['driving'],
    //   homeAddress: '228 San Angelo Ave, Benbrook, TX 76126',
    //   preferences: [
    //     'top_20_safety',
    //     'top_20_score',
    //     'school_bus_available',
    //     'diversity',
    //     'non_religious',
    //     'religious',
    //     'no_spanking',
    //     'after_school_care',
    //     'special_needs_education',
    //     'gifted_student',
    //     'english_as_second_language',
    //     'k12_school',
    //     'school_library',
    //     'foreign_languages',
    //     'theater',
    //     'dance',
    //     'vegan_vegetarian',
    //     'visual_arts',
    //     'computer_science',
    //     'music',
    //     'sports',
    //     'healthy_lunch_options',
    //     'science'
    //   ],
    //   chosen_school_ids: ['255939720698135058', '255939720698136082'],
    // }).then(function (response) {
    //   console.log('contact_schools response: ', response)
    //   window.res = response
    // }).catch(function (error) {
    //   console.log('contact_schools error: ', error)
    // })
  }
}
</script>
