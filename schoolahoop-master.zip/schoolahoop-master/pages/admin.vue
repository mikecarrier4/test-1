<template>
  <div id="admin" class="admin-page">
    <div class="container">
      <div class="row">
        <div class="col-md-9 ml-auto mr-auto">
          <h1 class="color-teal">
            Admin
          </h1>
          <a id="export_csv" :href="csv_url" download="all_quizzes.csv">{{ export_text }}</a>
          <input v-on:change="getQuizzes" type="checkbox" id="internal_filter" name="internal_filter" value="true" v-model:checked="internal_filter"><label for="internal_filter">Filter Internal Results</label>
          <table>
            <tr>
              <th>Email</th>
              <th>Parent's Name</th>
              <th>Child's Name</th>
              <th>Grade</th>
              <th>Date</th>
            </tr>
            <tr v-for="quiz in quizzes" :key="quiz.id">
              <td>{{ quiz.email }}</td>
              <td>{{ quiz.parent_name }}</td>
              <td>{{ quiz.name }}</td>
              <td>{{ quiz.grade }}</td>
              <td>{{ quiz.created_dt }}</td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
.admin-page {
  table {
    width: 100%;

    td,th {
      padding: 5px 10px;
      text-align: left;
    }
  }
}
</style>

<script type="text/javascript">
import axios from 'axios'

export default {
  data() {
    return {
      quizzes: [],
      quizzes_master: [],
      csv_url: '',
      export_text: '',
      internal_filter: true,
      schools: {},
      schools_retrieved: false,
    }
  },
  created() {
    this.getQuizzes()
  },
  methods: {
    async CreateCSVuri(quizzes) {
      const columns = ['email', 'created_dt', 'parent_name', 'child_name', 'grade', 'home_address', 'consider_commute', 'work_address', 'max_travel_time', 'preferences', 'transportation', 'school_filter_results', 'chosen_schools', 'user_ip']
      let csvRows = []
      let rowCount = 0

      const defaultPreferences = [
        'top_20_safety',
        'top_20_score',
        'school_bus_available',
        'diversity',
        'non_religious',
        'religious',
        'no_spanking',
        'after_school_care',
        'special_needs_education',
        'gifted_student_programs',
        'english_as_second_language',
        'k12_school',
        'school_library',
        'foreign_languages',
        'theater',
        'dance',
        'vegan_vegetarian',
        'visual_arts',
        'computer_science',
        'music',
        'sports',
        'healthy_lunch_options',
        'science',
      ]

      if (!this.schools_retrieved) {
        await axios.post('/.netlify/functions/get_all_schools').then((result) => {
          result.data.schools.forEach((school, index) => {
            this.schools[school.id] = school
          })
          this.schools_retrieved = true
        }).catch((err) => {
          console.log('get_allSchools err: ', err)
        })
      }

      if (this.schools_retrieved) {
        this.quizzes.forEach((quiz, index) => {
          let cellCount = 0
          let csvRow = []

          if (rowCount === 0) {
            columns.forEach(function (column, index) {
              csvRow[cellCount] = column
              cellCount++
            })
            csvRows[rowCount] = csvRow
            cellCount = 0
            csvRow = []
            rowCount++
          }

          columns.forEach((column, index) => {
            let value = ''

            switch (column) {
              case 'child_name':
                value = quiz.name
                break

              case 'preferences':
                const preferences = []
                defaultPreferences.forEach(function (defPref, index) {
                  if (quiz.preferences[defPref] !== undefined && quiz.preferences[defPref] === true) {
                    preferences[preferences.length] = defPref
                  }
                })
                value = preferences.join(', ')
                break

              case 'chosen_schools':
                if (quiz.chosen_school_ids !== undefined && quiz.chosen_school_ids.length > 0) {
                  const schoolNames = []
                  quiz.chosen_school_ids.forEach((schoolId, index) => {
                    schoolNames[schoolNames.length] = this.schools[schoolId].name + ', ' + this.schools[schoolId].contact_1_name + ', ' + this.schools[schoolId].contact_1_email
                  })
                  value = schoolNames.join("\n")
                }
                break

              case 'school_filter_results':
                if (quiz.filter_school_ids !== undefined && quiz.filter_school_ids.length > 0) {
                  const schoolNames = []
                  quiz.filter_school_ids.forEach((schoolId, index) => {
                    schoolNames[schoolNames.length] = this.schools[schoolId].name
                  })
                  value = schoolNames.join(', ')
                }
                break

              default:
                if (quiz[column] === undefined) {
                  quiz[column] = ''
                }
                value = quiz[column]
                break
            }

            csvRow[cellCount] = '"' + value.toString().replace(/["#]/g, "'") + '"'
            cellCount++
          })

          csvRows[rowCount] = csvRow
          rowCount++
        })

        const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map(e => e.join(',')).join('\n')
        this.csv_url = encodeURI(csvContent)
        this.export_text = 'Export CSV'
        return true
      } else {
        return false
      }
    },
    async getQuizzes() {
      this.loading = true

      let quizzes = []

      if (this.quizzes_master.length == 0) {
        await axios.post('/.netlify/functions/get_quizzes').then((results) => {
          this.loading = false
          
          results.data.quizzes.forEach(function (quiz, index) {
            if (quiz.email === undefined || quiz.email.trim() === '') {
              quiz.email = 'anonymous'
            }
            if (quiz.parent_name === undefined || quiz.parent_name.trim() === '') {
              quiz.parent_name = 'anonymous'
            }

            quiz.ts = Number(String(quiz.ts).substr(0, 13))
            const dt = new Date(quiz.ts)
            quiz.created_dt = dt.toJSON().replace(/[A-Z+]/g, ' ').substr(0, 19)
            quizzes[index] = quiz
          })
          quizzes.sort((a, b) => (a.email > b.email) ? 1 : -1)
          this.quizzes_master = quizzes
        }).catch((err) => {
          this.loading = false
          console.log('get_quizzes error: ', err)
        }) 
      }

      if (this.quizzes_master.length > 0) {
        let filter_ips = ['95.136.34.107','67.160.238.153','108.227.76.100','73.88.95.173']

        if (this.internal_filter) {
          quizzes = []
          let count = 0
          
          this.quizzes_master.forEach(function(quiz, index){
            let filter = false

            if (quiz.name.toLowerCase().includes('test') || quiz.parent_name.toLowerCase().includes('test')) {
              filter = true
            }

            if (quiz.email.toLowerCase().includes('joinlicoln') || quiz.email.toLowerCase().includes('joincoln') || quiz.email.toLowerCase().includes('joinlincoln') || quiz.email.toLowerCase().includes('milesproduction') || quiz.email.toLowerCase().includes('symantix.co')) {
              filter = true
            }

            if (quiz.home_address.toLowerCase().includes('1 main st')) {
              filter = true
            }

            filter_ips.forEach(function(ip, i2){
              if (quiz.user_ip == ip) {
                filter = true
              }
            })
            
            if (!filter) {
              quizzes[count] = quiz
              count++
            }
          })
          this.quizzes = quizzes
        } else {
          this.quizzes = this.quizzes_master
        }

        this.CreateCSVuri()
      }
    }
  },
  mounted() {
    this.$store.commit('viewConfig/showFooterOnMobile')
  }
}
</script>
<style lang="scss">
  #export_csv {
    margin-right: 10px;
  }
</style>
