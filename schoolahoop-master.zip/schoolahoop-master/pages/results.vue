<template>
  <div class="results-page">
    <div class="container">
      <div class="row">
        <div class="col mr-auto ml-auto">
          <template v-if="emptyResults">
            <div class="text">
              <template v-if="dataError">
                <p>
                  There was an error when fetching schools, please try again.
                </p>
                <p>
                  If this error persists, please feel free to contact us at
                  <a mailto="contact@schoolahoop.org">contact@schoolahoop.org</a>.
                </p>
              </template>
              <template v-else>
                <p>Sorry! We couldn't find any results with your search.</p>
                <ul>
                  <li>
                    Right now we only search for schools in Tarrant County, TX
                  </li>
                  <li>
                    Double check that you entered your address correctly
                  </li>
                  <li>
                    You may have limited your travel methods or travel time too severely
                  </li>
                </ul>
              </template>
              <nuxt-link to="/quiz?step=HomeAddressStep">
                <btn
                  label="Back to Quiz"
                  class="button button--block"
                />
              </nuxt-link>
            </div>
          </template>
          <template v-else>
            <h1>{{ userName() }}'s Options</h1>
            <p class="text-center">
              Select the schools you're interested in
            </p>
            <div class="results">
              <School
                v-for="school in schools"
                :id="school.id"
                :key="school.id"
                :name="school.name"
                :tags="school.tags"
                :school-info="school.school_info"
                :hours="school.hours"
                :distance="school.distance"
                :address="school.address"
                :mission-statement="school.missionStatement"
                :application-period="school.application_period"
                :image-url="school.image_name"
                :student-teacher-ratio="validStudentTeacherRatio(school.student_teacher_ratio)"
                :ethnicities="school.ethnicities"
                :coed="school.coed"
                :travel-time="school.travel_time"
                :start-time="school.start_time"
                :end-time="school.end_time"
              />
            </div>
            <div class="text-center results-footer">
              <p class="text-center results__num-chosen">
                {{ numSchoolsChosenStr }} chosen
              </p>
              <btn
                label="Continue"
                class="button button--block"
                style="padding-left:60px; padding-right:60px;"
                :disabled="zeroSchoolsChosen"
                @clicked="goToSendResults"
              />
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import School from '~/components/School'
import Btn from '~/components/Btn'

export default {
  components: { School, Btn },
  data() {
    return {
      dataError: false,
      schools: [],
    }
  },
  computed: {
    emptyResults() {
      return this.schools.length === 0
    },
    ...mapGetters({
      numSchoolsChosen: 'user/numSchoolsChosen',
      numSchoolsChosenStr: 'user/numSchoolsChosenStr',
    }),
    zeroSchoolsChosen() {
      return this.numSchoolsChosen === 0
    },
  },
  mounted() {
    this.schools = this.$store.state.user.fields.schools

    if (this.$route.params.error) {
      this.dataError = true
    }

    this.$mixpanel.track('Results viewed')
    this.$store.commit('viewConfig/hideFooterOnMobile')
  },
  methods: {
    userName() {
      return this.$store.getters['user/fields']('name')
    },
    goToSendResults() {
      this.$router.push({ name: 'send-results' })
    },
    validCoed(coed) {
    },
    validStudentTeacherRatio(ratio) {
      const type = typeof ratio

      switch (type) {
        case 'number':
          return ratio
        default:
          return undefined
      }
    }
  },
}
</script>

<style lang="scss">
.results {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin: 30px 0;

  &__num-chosen {
    margin: 10px auto;
    opacity: 1;
    font-weight: bold;
    display: block;

    @media(min-width: 576px) {
      display: inline-block;
    }
  }
}

.text {
  max-width: 500px;
  margin: 20px auto;

  li {
    opacity: 0.5;
  }
}

.results-page {
  position: relative;

  a {
    color: $red;
    cursor: pointer;
  }
}

.results-footer {
  background-color: $beige;
  padding: 10px 0;
  position: sticky;
  bottom: 0;
}

@media(max-width: 600px) {
  .results-footer {
    background-color: $white;
  }
}
</style>
