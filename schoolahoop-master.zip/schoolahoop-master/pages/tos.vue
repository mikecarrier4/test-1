<template>
  <div class="tos-page">
    <div class="container">
      <div class="row">
        <div class="col-md-9 mr-auto ml-auto">
          <h1 class="color-teal">
            Terms of Service
          </h1>
          <p>Lincoln Network, Inc.</p>
          <p>Last Revised: January 5, 2020</p>
          <p>Welcome to Lincoln Network.</p>
          <p>To make these Terms (the “Terms”) easier to read, we will sometimes refer to LINCOLN NETWORK, INC. (including our directors, officers, members, managers, employees, affiliates, successors and assigns) as “our”, “we”, or “us”; we will refer to you as “you” or a derivative of you; and we will refer to a User who creates an account on LINCOLN NETWORK, INC. as a “User(s)”. In some instances when describing interactions between Users we will differentiate between “Parent” Users and “service provider” Users.</p>
          <p>
            Please review these Terms and the LINCOLN NETWORK, INC. Privacy Policy (“Privacy Policy”), located at (insert Link to Privacy Policy), before you begin using LINCOLN NETWORK, INC. because the Terms and the Privacy Policy create a legal agreement between you and LINCOLN NETWORK, INC.. By using LINCOLN NETWORK, INC. or by clicking to accept or agree to the Terms when this option is made available to you, you accept and agree to be bound and abide by these Terms, and our Privacy Policy, found at [INSERT URL] (“Privacy Policy”), incorporated herein by reference. If you do not agree to these Terms and/or the Privacy Policy, you must not access or use LINCOLN NETWORK, INC..
          </p>

          <h2>GENERAL</h2>
          <h3>About the App</h3>
          <p>
            LINCOLN NETWORK, INC. is a platform accessible via website and mobile application (cumulatively, the “App”) that allows a User to create a LINCOLN NETWORK, INC. account (“Account”) using the App. To create an Account, a User will have to create a Username and set a password. Then, the User will need to create an Account profile (“Profile”), the information contained therein shall include, at a minimum: Full legal name, occupation, birth date, gender, phone number, email Address, current home address, a personal description and at least one outside reference shall also be required. This information and all other input to the User profile may be referred to within this document as “Information.” Once a User has created an Account and provided adequate Information to the Profile, that User can begin using the Platform which connects parents with Educational Options in their area. These User interactions may be referred to as “Arrangement(s)” within this document.
          </p>
          <h3>Privacy Policy</h3>
          <p>Our Privacy Policy describes what information we collect from you, how we collect information from you, and how we use and share information we collect from you. For more information, please visit Link to Privacy Policy.</p>
          <h3>Eligibility to Use the App</h3>
          <p>You must be at least 21 years old and a citizen or permanent resident of the United States in order to create an Account or use the App. By using the App, you represent and warrant that you are at least 18 years of age and meet all of the eligibility requirements of these Terms. If you do not meet these requirements or, if for any reason, you do not agree with all of the terms and provisions of these Terms, you must stop using the App immediately.</p>
          <h2>SAFETY</h2>
          <h3>Interactions with other Users</h3>
          <p>LINCOLN NETWORK, INC. has built the App in order to provide Users with the ability to become more informed about educational choices for your children. </p>
          <p>You agree and acknowledge that your experience with the educational institutions found on this app are not something that is within the control of Lincoln Network. The ultimate goal of this app is to allow parents to search for educational options in their area. We are aggregators of information and are not responsible for any claims or representations made by any school or program.</p>
          <p>LINCOLN NETWORK, INC. MAKES NO REPRESENTATIONS OR WARRANTIES AS TO THE QUALITY OF EDUCATIONAL SERVICES. YOU ARE SOLELY RESPONSIBLE FOR YOUR INTERACTIONS WITH OTHER USERS. LINCOLN NETWORK, INC. ALSO DOES NOT VERIFY ALL CONTENT OR INFORMATION POSTED BY USERS.  LINCOLN NETWORK, INC. SERVES AS A PLATFORM TO INTRODUCE PEOPLE WHO CAN, IF THEY CHOOSE, ENTER VOLUNTARILY INTO AN ARRANGEMENT THAT IS MUTUALLY BENEFICIAL. LINCOLN NETWORK, INC. IS NOT RESPONSIBLE FOR REAL OR PERSONAL PROPERTY THEFT, DAMAGE OR DESTRUCTION, INJURY, SICKNESS, DEATH OF ANY PERSON OR ANIMAL OR ANY OTHER NEGATIVE CONSEQUENCE THAT MAY ARISE FROM ANY INTERACTION WITH A SCHOOL OR EDUCATIONAL PROGAM. </p>
          <h2>Account Information and Right to Use the App</h2>
          <h3>Account Creation</h3>
          <p>To register for the App, you will be asked to provide certain registration details or other information. It is a condition of your use of the App that all the information you provide is, current, complete, accurate, and not false or misleading. You agree that all information you provide to register with App, is governed by our Privacy Policy, and you consent to all actions we take with respect to your information consistent with our Privacy Policy. Additionally, you will be asked to provide the applicable billing information.</p>
          <h3>Account and User Information Protection</h3>
          <p>Upon creation of your Account, you will create a unique Username and password (“User Information”). It is your responsibility to protect your personal data and maintain the confidentiality of your User Information. You agree to notify us immediately if you suspect or become aware of any unauthorized use of your Account or User Information, or any unauthorized breach of your Account or User Information. You also acknowledge that your Account and User Information is personal to you and agree not to allow any other person to access the App or any portion of it using your User Information. We have the right to disable any Account, User Information, or other identifier, whether chosen by you or provided by us, at any time in our sole discretion, for any or for no reason, including if, in our opinion, you have violated any provision of these Terms.</p>
          <h3>Unauthorized Use of Your Account</h3>
          <p>LINCOLN NETWORK, INC. will not be liable for any loss that you may incur as a result of someone else using your Account or User Information, either with or without your knowledge. To the extent allowable by law, you shall be liable for any expenses, including usage charges and fines, fees, civil judgments, and reasonable attorney’s fees for your failure to safeguard your User Information and/or promptly notify LINCOLN NETWORK, INC. about unauthorized use of your account or breach of your account information or password. </p>
          <h3>No Guarantee of Access</h3>
          <p>We reserve the right to withdraw or amend the App, and any feature or material we provide as part of the App, in our sole discretion without notice. In addition, the App may automatically download and install upgrades and updates. We will not be liable if for any reason all or any part of the App is unavailable at any time or for any period.</p>
          <h3>Use and Access Restrictions</h3>
          <p>We reserve the right to refuse the use of, or access to, the App to anyone, for any reason, at any time. From time to time, we may restrict access to the App, or any portion thereof, to Users, including registered Users. We may, in our sole discretion, terminate your right to use the App with or without cause at any time, and may prevent your future use of the App. You may terminate this Agreement by simply discontinuing use of the App. </p>
          <h3>Your Responsibilities After Termination</h3>
          <p>In the event that you terminate, or we terminate your right to use the App, LINCOLN NETWORK, INC. may restrict your access to any content or material that you may have used in connection with the App. The restriction of your use of the App shall survive such termination, and you agree to be bound by those terms. We reserve all rights that are not expressly granted to you under these Terms.</p>
          <h3>Your Rights to Use the App</h3>
          <p>These Terms permit you to use the App for your personal, non-commercial use only. Subject to these Terms, we hereby grant you a limited, revocable, personal, non-sublicenseable, non-transferable, and non-exclusive license to access and use the App. You will use the App in full compliance with all applicable laws and regulations with regard to your use of the Apps, including all applicable traffic laws and official race rules.</p>
          <h3>Intellectual Property Ownership  </h3>
          <p>You acknowledge and agree that by providing any Content on the App, you grant us the right to use, reproduce, modify, perform, display, distribute, and otherwise disclose to third parties any such material for any purpose to LINCOLN NETWORK, INC. in perpetuity.</p>
          <p>
            You may not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, frame, create derivative works from, transfer, or otherwise use in any other way for commercial or public purposes, in whole or in part, any information, software, products, materials, or services obtained from the App, except for the purposes expressly provided herein, without LINCOLN NETWORK, INC.’s prior written approval.  If you wish to make any use of material provided as part of the App other than as set out in these Terms, please address your request to: Ops@joinlincoln.org.
            If you print, copy, modify, download, or otherwise use or provide any other person with access to any part of the App in breach of the Terms, your right to use the App will stop immediately and you must, at our option, return or destroy any copies of the materials you have made. No right, title, or interest in or to the App, or any content on the App is transferred to you. Any use of the App not expressly permitted by these Terms is a breach of these Terms and may violate copyright, trademark, and other laws. We reserve all rights that are not expressly granted to you under these Terms.
          </p>
          <h2>Use and Content Restrictions</h2>
          <h3>Use Limitations </h3>
          <p>
            In addition to complying with other provisions of these Terms, you agree that you will not:
            Use the App for any unlawful purpose or for the promotion of illegal activities;
            Attempt to, or harass, abuse, or harm another person or group;
            Provide others with access to or use of your Account, or use the Account or any other User without permission;
            Provide false or inaccurate information when registering for or using Account;
            Use the App for the purpose of exploiting, harming, or attempting to exploit or harm minors in any way by exposing them to inappropriate content, asking for personally identifiable information, or otherwise;
            Make any automated use of the App, or take any action that we deem to impose or to potentially impose an unreasonable or disproportionately large load on the App;
            Use any manual process to monitor or copy any of the material on the App or for any other unauthorized purpose without our prior written consent;
            Copy, adapt, modify, create derivative works of, distribute, sell, or lease any part of the App or materials we provide as part of the App;
            Reverse engineer or attempt to extract the any source code of the App, unless applicable laws prohibit these restrictions or you have our written permission to do so;
            Use any software, technology, or device to scrape, spider, or crawl the App or harvest or manipulate data; or
            Introduce any viruses, trojan horses, worms, logic bombs, or other material that is malicious or technologically harmful;
            Bypass any measures we take to restrict access to the App; and
            Otherwise interfere or attempt to interfere with the proper functioning of the App.
          </p>
          <p>Unauthorized use may result in criminal and/or civil prosecution under Federal, State and local law.  If you become aware of misuse of our App, please contact us at OPS@joinlincoln.org.</p>
          <p>
            In addition to complying with other provisions of these Terms, you agree that you will not:
            Use the App for any unlawful purpose or for the promotion of illegal activities;
            Attempt to, or harass, abuse, or harm another person or group;
            Provide others with access to or use of your Account, or use the Account or any other User without permission;
            Provide false or inaccurate information when registering for or using Account;
            Use the App for the purpose of exploiting, harming, or attempting to exploit or harm minors in any way by exposing them to inappropriate content, asking for personally identifiable information, or otherwise;
            Make any automated use of the App, or take any action that we deem to impose or to potentially impose an unreasonable or disproportionately large load on the App;
            Use any manual process to monitor or copy any of the material on the App or for any other unauthorized purpose without our prior written consent;
            Copy, adapt, modify, create derivative works of, distribute, sell, or lease any part of the App or materials we provide as part of the App;
            Reverse engineer or attempt to extract the any source code of the App, unless applicable laws prohibit these restrictions or you have our written permission to do so;
            Use any software, technology, or device to scrape, spider, or crawl the App or harvest or manipulate data; or
            Introduce any viruses, trojan horses, worms, logic bombs, or other material that is malicious or technologically harmful;
            Bypass any measures we take to restrict access to the App; and
            Otherwise interfere or attempt to interfere with the proper functioning of the App.
          </p>
          <p>Unauthorized use may result in criminal and/or civil prosecution under Federal, State and local law.  If you become aware of misuse of our App, please contact us at OPS@joinlincoln.org.User Content</p>
          <p>The App provides you (and other Users) the ability to post, submit, publish, display, or transmit to other Users (hereinafter, “post”) content, information, materials, images, and other material (collectively, “Content”) on or through the App.</p>
          <p>All Content you post must comply with these Terms, including the Content Standards herein. Any Content you post to the App will be considered non-confidential and non-proprietary. By providing any Content on the App, you grant us the right to use, reproduce, modify, perform, display, distribute, and otherwise disclose to third parties any such material for any purpose.</p>
          <p>
            You represent and warrant that:
            You own or control all rights in and to the Content and have the right to grant the license granted above to us.
            All of your Content is compliant with these Terms.
            You understand and acknowledge that you are responsible for any Content you submit or contribute, and you, not LINCOLN NETWORK, INC., have fully responsibility for such content, including its legality, reliability, accuracy, and appropriateness.
            We are not responsible or liable to any third party for the content or accuracy of any Content posted by you or any other User of the App.
          </p>
          <h3>Monitoring and Enforcement </h3>
          <p>
            We have the right to:
            Remove or refuse to post any Content for any or no reason in our sole discretion;
            Take any action with respect to any Content that we deem necessary or appropriate in our sole discretion, including if we believe that such Content violates the Terms, including the Content Standards, infringes any intellectual property right or other right of any person or entity, threatens the personal safety of Users or the public, or could create liability for LINCOLN NETWORK, INC.;
            Disclose your identity or other information about you to any third party who claims that material posted by you violates their rights, including their intellectual property rights or their right to privacy;
            Take appropriate legal action, including without limitation, referral to law enforcement, for any illegal or unauthorized use of the App; and
            Terminate or suspend your access to all or part of the App for any or no reason, including without limitation, any violation of these Terms.
          </p>
          <p>Without limiting the foregoing, we have the right to fully cooperate with any law enforcement authorities or court order requesting or directing us to disclose the identity or other information of anyone posting any materials on or through the App. YOU WAIVE AND HOLD HARMLESS THE COMPANY AND ITS AFFILIATES, LICENSEES AND SERVICE PROVIDERS FROM ANY CLAIMS RESULTING FROM ANY ACTION TAKEN BY ANY OF THE FOREGOING PARTIES DURING, OR TAKEN AS A CONSEQUENCE OF, INVESTIGATIONS BY EITHER SUCH PARTIES OR LAW ENFORCEMENT AUTHORITIES.</p>
          <p>We cannot and do not review any material before it is posted on the App and cannot ensure prompt removal of objectionable material after it has been posted. Accordingly, we assume no liability for any action or inaction regarding transmissions, communications, or content provided by any User or third party. We have no liability or responsibility to anyone for performance or nonperformance of the activities described in this section.</p>
          <h3>Content Standards</h3>
          <p>
            These content standards (“Content Standards”) apply to any and all Content and use of the App. Content must in their entirety comply with all applicable federal, state, local, and international laws and regulations. Without limiting the foregoing, Content must not:
            Contain any material that is defamatory, obscene, indecent, abusive, offensive, harassing, violent, hateful, inflammatory, or otherwise objectionable;
            Promote sexually explicit or pornographic material, violence, or discrimination based on race, sex, religion, nationality, disability, sexual orientation, or age;
            Infringe any patent, trademark, trade secret, copyright, or other intellectual property or other rights of any other person;
            Violate the legal rights (including the rights of publicity and privacy) of others or contain any material that could give rise to any civil or criminal liability under applicable laws or regulations;
            Be likely to deceive any person;
            Promote any illegal activity, or advocate, promote, or assist any unlawful act;
            Cause annoyance, inconvenience, or needless anxiety or be likely to upset, embarrass, alarm, or annoy any other person;
            Impersonate any person, or misrepresent your identity or affiliation with any person or organization;
            Involve commercial activities or sales, such as contests, sweepstakes and other sales promotions, barter, or advertising; and
            Give the impression that they emanate from or are endorsed by us or any other person or entity, if this is not the case.
          </p>
          <p>LINCOLN NETWORK, INC. is a platform designed to allow User to create mutually beneficial relationships with regard to helping parents find eductional options for their children. LINCOLN NETWORK, INC. in its SOLE DISCRETION has the right to remove any User for posting any content that is in violation of the above rules or generally not in furtherance of the stated objective of the platform. Failure to abide by these rules shall result in the termination of your account and, if necessary, referral to appropriate authorities.</p>
          <h3>Copyright Complaints </h3>
          <p>
            All content that you use on the App must comply with U.S. copyright law, depending on jurisdiction. If you are the copyright owner or an agent thereof and believe, in good faith, that any materials currently being used in connection with the App infringe upon your copyrights, you may submit a notification pursuant to the Digital Millennium Copyright Act (see 17 U.S.C 512) (“DMCA”) by sending the following information in writing to LINCOLN NETWORK, INC.’s designated copyright agent at Ops@joinlincoln.org.
            The date of your notification;
            A physical or electronic signature of a person authorized to act on behalf of the owner of an exclusive right that is allegedly infringed;
            A description of the copyrighted work claimed to have been infringed, or, if multiple copyrighted works at a single online site are covered by a single notification, a representative list of such works at that site;
            A description of the material that is claimed to be infringing or to be the subject of infringing activity and information sufficient to enable us to locate such work;
            Information reasonably sufficient to permit LINCOLN NETWORK, INC. to contact you, such as an address, telephone number, and/or email address;
            A statement that you have a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law; and
            A statement that the information in the notification is accurate, and under penalty of perjury, that you are authorized to act on behalf of the owner of an exclusive right that is allegedly infringed
          </p>
          <h2>Liability, Indemnification, and Disputes</h2>
          <h3>Assumption of Risk</h3>
          <p>The information presented on or through the App is made available solely for general information purposes. We do not warrant the accuracy, completeness, or usefulness of this information. Any reliance you place on such information is strictly at your own risk. We disclaim all liability and responsibility arising from any reliance placed on such materials by you or any other visitor to the App, or by anyone who may be informed of any of its contents.</p>
          <p>The App contains Content posted by Users, and all statements and/or opinions expressed in such Content (other than the Content provided by LINCOLN NETWORK, INC.) are solely the opinions and the responsibility of the User posting such Content, and not the opinion LINCOLN NETWORK, INC.. We are not responsible, or liable to you or any third party, for accuracy, truthfulness, reliability or otherwise of any Content posted by Users.</p>
          <p>LINCOLN NETWORK, INC. SERVES AS A PLATFORM TO INTRODUCE PEOPLE WHO CAN, IF THEY CHOOSE, ENTER VOLUNTARILY INTO AN ARRANGEMENT THAT IS MUTUALLY BENEFICIAL. LINCOLN NETWORK, INC. IS NOT RESPONSIBLE FOR ANY LOST, STOLEN OR DAMAGED PROPERTY, INJURY, SICKNESS OR DEATH OF ANY PERSON OR ANIMAL OR ANY OTHER NEGATIVE CONSEQUENCE THAT MAY ARISE FROM ANY INTERACTION WITH ANOTHER USER. IF YOU ARE IN ANY WAY CONCERNED ABOUT ANOTHER USERS SUITABILITY FOR MEMBERSHIP ON THIS APP, PLEASE LET US KNOW IMMEDIATELY. BY PARTICIPATING ON THIS APP YOU ARE ACKNOWLEDGING THAT YOU ARE AWARE OF THE POTENTIAL RISKS AND FURTHER ACKNOWLEDGING THE LINCOLN NETWORK, INC. IS NOT RESPONSIBLE FOR ANY LOSSES ASSOCIATED WITH A NEGATIVE USER EXPERINENCE.  </p>
          <h3>No Warranties </h3>
          <p>THE APP, AND ANY CONTENT OR INFORMATION THEREIN, IS PROVIDED “AS IS,” WITHOUT WARRANTY OF ANY KIND. LINCOLN NETWORK, INC. MAKES NO EXPRESS OR IMPLIED WARRANTIES AND CONDITIONS REGARDING THE APP OR THE USE OR PERFORMANCE OF THE APP. WITHOUT LIMITING THE FOREGOING, LINCOLN NETWORK, INC. EXPRESSLY DISCLAIMS ALL WARRANTIES, WHETHER EXPRESS, IMPLIED, OR STATUTORY, REGARDING THE APP (INCLUDING ANY CONTENT AND INFORMATION THEREIN) INCLUDING WITHOUT LIMITATION ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, SECURITY, ACCURACY, AND NON-INFRINGEMENT. WITHOUT LIMITING THE FOREGOING, LINCOLN NETWORK, INC. MAKES NO WARRANTY OR REPRESENTATION THAT ACCESS TO OR OPERATION OF THE APP WILL BE UNINTERRUPTED OR ERROR FREE. YOU ASSUME FULL RESPONSIBILITY AND RISK OF LOSS RESULTING FROM YOUR USE OF THE APP. </p>
          <p>SOME JURISDICTIONS LIMIT OR DO NOT PERMIT DISCLAIMERS OF WARRANTY, SO THIS PROVISION MAY NOT APPLY TO YOU.</p>
          <h3>Limitation of Liability</h3>
          <p>
            TO THE EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL LINCOLN NETWORK, INC. BE LIABLE TO YOU FOR ANY INTERRUPTION OF THE APP, LOSS OF USE OR OTHER CONSEQUENTIAL, INCIDENTAL, INDIRECT, EXEMPLARY OR PUNITIVE DAMAGES, HOWEVER ARISING. FURTHERMORE, LINCOLN NETWORK, INC. WILL NOT BE LIABLE TO YOU FOR:
            ANY DELAY IN ACCESSING AND/OR INABILITY TO ACCESS THE SERVICE, FOR ANY REASON WHATSOEVER;
            THE CONDUCT (WHETHER SUCH CONDUCT OCCURS IN THE APP OR OUTSIDE OF THE APP) OF OTHER USERS OR CONTENT POSTED BY OTHER USERS OR THIRD PARTIES; OR
            ANY LOST, STOLEN OR DAMAGED REAL OR PERSONAL PROPERTY; OR
            ANY INJURY, SICKNESS OR DEATH OF ANY PERSON OR ANIMAL; OR
            ANY MEDICAL ARISING FROM INCIDENTS THAT OCCUR DURING A USER ARRANGEMENT; OR
            UNAUTHORIZED ACCESS, USE OR ALTERATION OF YOUR CONTENT.
          </p>
          <p>LINCOLN NETWORK, INC.’S LIABILITY TO YOU FOR DAMAGES FROM ANY CAUSE WHATSOEVER, AND REGARDLESS OF THE FORM OF ACTION, WHETHER IN CONTRACT (EVEN IF A FUNDAMENTAL BREACH), TORT (INCLUDING NEGLIGENCE), PRODUCT LIABILITY OR OTHERWISE, WILL BE LIMITED TO THE TOTAL FEES PAID BY YOU FOR THE APP, IF ANY.</p>
          <p>SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF CERTAIN DAMAGES, SO SOME OR ALL OF THE EXCLUSIONS AND LIMITATIONS IN THIS SECTION MAY NOT APPLY TO YOU.</p>
          <h3>Indemnification by You</h3>
          <p>You agree to indemnify and hold harmless LINCOLN NETWORK, INC. from any claim or demand, including reasonable attorneys’ fees, INCURRED BY LINCOLN NETWORK, INC. due to, or arising out of, your breach of these terms, misuse of the App, violation of any law, or the ACTIONS or omissions of aNY OTHER USER OR third-party. AS PART OF YOUR SUBSCRIPTION TO LINCOLN NETWORK, INC. PROVIDES INSURANCE TO COVER POSSIBLE LIABILITY INCURRED DURING USER ARRANGEMENTS. ANY DAMAGES or LIABILITIES THAT EXCEED THE INSURANCE PROVIDED BY LINCOLN NETWORK, INC. WILL BE THE SOLE RESPONSIBILITY OF THE USER, AND USER SHALL INDEMNIFY LINCOLN NETWORK, INC. FOR ANY LIABILITIES OR DAMAGES THAT EXCEED THAT THRESHOLD, INCLUDING REASONABLE ATTORNEYS FEEs, COSTS OF COURT ANd ANY OTHER REASONABLE EXPENSES INCURRED BY LINCOLN NETWORK, INC. ARISING from or realting to THe matter in controversy</p>
          <h3>Limitation on Time to File Claims</h3>
          <p>You agree that any cause of action related to or arising out of your use of the app must commence within ONE (1) year after the cause of action accrues.  Otherwise, such cause of action is permanently barred.</p>
          <h3>Arbitration, Class-Action Waiver and Jury Trial Waiver</h3>
          <p>You agree and acknowledge that the exclusive means for resolving any dispute or claim arising from the Terms or your use of the App shall be binding arbitration by a neutral arbitrator under the Consumer Arbitration Rules of the American Arbitration Association applying California law. </p>
          <p>Any action to enforce an arbitration decision, including any proceeding to confirm, modify, or vacate an arbitration decision, may be commenced in any court of competent jurisdiction. In the event that any or all of the arbitration decision is held to be unenforceable, any litigation against LINCOLN NETWORK, INC. may be commenced only in the federal or state courts located in Raleigh, North Carolina. You hereby irrevocably consent to the jurisdiction of those courts for such purposes.</p>
          <p>Any claim relating to the App shall be governed by the laws of the state of North Carolina, without regard to any conflict of law provisions</p>
          <h2>Miscellaneous</h2>
          <h3>Contact Information </h3>
          <p>LINCOLN NETWORK, INC. is the official legal name of LINCOLN NETWORK, INC., and we are a Delaware Non-Profit Corporation.</p>
          <p>Please send all feedback, comments, requests for technical support, and other communications relating to the App should be directed to: OPS@Joinlinoln.org.</p>
          <h3>Enforceability </h3>
          <p>Even if LINCOLN NETWORK, INC. does not require strict compliance with these Terms in each instance, you are still obligated to comply with these Terms. Our failure to enforce, at any time, any of the provisions, conditions, or requirements of these Terms, or the failure to require, at any time, performance by you of any of the provisions of these Terms, will in no way waive your obligation to comply with any of the provisions of these Terms, or our ability to enforce each and every such provision as written.</p>
          <p>Any and all waivers by LINCOLN NETWORK, INC. of any provision, condition, or requirement of these Terms will only be effective against LINCOLN NETWORK, INC. if it is in writing and signed by an authorized officer of LINCOLN NETWORK, INC.. No waiver by LINCOLN NETWORK, INC. of any term or condition set out herein shall be deemed a further or continuing waiver of such term or condition or a waiver of any other term or condition, and any failure of LINCOLN NETWORK, INC. to assert a right or provision under these Terms shall not constitute a waiver of such right or provision.</p>
          <h3>Entire Agreement &amp; Severability </h3>
          <p>These Terms and our Privacy Policy constitute the sole and entire agreement between you and LINCOLN NETWORK, INC. regarding the App and supersede all prior and contemporaneous understandings, agreements, representations, and warranties, both written and oral, regarding the App.</p>
          <p>If any provision of these Terms is held by an arbitrator or court or other tribunal of competent jurisdiction to be invalid, illegal or unenforceable for any reason, such provision shall be eliminated or limited to the minimum extent such that the remaining provisions of the Terms will continue in full force and effect. Our rights under these Terms will survive any termination of these Terms.</p>
          <h3>General Acknowledgment</h3>
          <p>YOU ACKNOWLEDGE THAT YOU HAVE READ AND UNDERSTAND THESE TERMS, AND WILL BE BOUND BY THESE TERMS. YOU FURTHER ACKNOWLEDGE THAT THESE TERMS OF USE TOGETHER WITH THE PRIVACY POLICY AT [INSERT LINK TO PRIVACY POLICY] REPRESENT THE COMPLETE AND EXCLUSIVE STATEMENT OF THE AGREEMENT BETWEEN US, AND SUPERSEDE ANY PROPOSAL OR PRIOR AGREEMENT ORAL OR WRITTEN, AND ANY OTHER COMMUNICATIONS BETWEEN US RELATING TO THE SUBJECT MATTER OF THIS AGREEMENT.</p>
          <h3>Links to Third-Party Websites, Applications, Software, or Content</h3>
          <p>As part of the App, we may provide you with convenient links to third-party website(s) as well as content or items belonging to or originating from third-parties (collectively, “Third-Party Content”).  These links are provided as a courtesy to Users.  LINCOLN NETWORK, INC. has no control over Third-Party Content or the promotions, materials, information, goods or services advertised by or available from Third-Party Content. Such Third-Party Content is not investigated, monitored or checked for accuracy, appropriateness, or completeness by LINCOLN NETWORK, INC.. </p>
          <p>We are not responsible for any Third-Party Content posted on, available through or installed from the App, including the content, accuracy, offensiveness, opinions, reliability, privacy practices or other policies of or contained in the Third-party Content.  </p>
          <p>Our inclusion of, linking to, or permitting the use or installation of any Third-Party Content does not imply approval or endorsement by LINCOLN NETWORK, INC.. If you decide to leave the App and access or use any Third-Party Content, you do so at your own risk and you should be aware that our terms and policies no longer govern. You should review the applicable terms and policies, including privacy and data gathering practices, of any third-party site or application to which you navigate from the App.</p>
          <h3>Email and Legal Notice </h3>
          <p>Communications made through the LINCOLN NETWORK, INC.’s e-mail and messaging system, if and when available, will not constitute legal notice to LINCOLN NETWORK, INC. in any situation where notice to LINCOLN NETWORK, INC. is required by contract or any law or regulation.</p>
          <h3>You Consent to Receive Electronic Communications</h3>
          <p>For contractual purposes, you (i) consent to receive communications from LINCOLN NETWORK, INC. in an electronic form via the email address you have submitted; and (ii) agree that all Terms, agreements, notices, disclosures, and other communications that LINCOLN NETWORK, INC. provides to you electronically satisfy any legal requirement that such communication would satisfy if it were in writing.  The foregoing does not affect your non-waivable rights. We may also use your email address, to send you other messages, consistent with and as described in more detail in our Privacy Policy located at _INSERT LINK TO PP. You may opt out of such email by changing your account settings or sending notice of opt out to Ops@joinlincoln.org.</p>
          <h3>We May Amend the App and these Terms</h3>
          <p>We may update the App (including its content, materials, and features) from time to time. Please be advised that any content contained on the App may not necessarily be complete or up-to-date. Any of the material on the App may be out of date at any given time, and we are under no obligation to update such material.</p>
          <p>We may revise and update these Terms from time to time in our sole discretion. All changes become effectively immediately when we post them and upon your continued use of the App. </p>
          <p>It is your responsibility to check the App from time to time, so you are aware of any changes. If you continue to use the App after we post revised Terms or a revised Privacy Policy, you signify your agreement to such revised Terms. However, we shall notify you of material changes to the terms by posting a notice in the App and/or sending an email to the email address you provided in your profile upon registration. For this reason, you should keep your contact and profile information current. If, following such changes, you no longer agree to these Terms or the Privacy Policy, you must discontinue using the App.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    mounted() {
      this.$store.commit('viewConfig/showFooterOnMobile')
    },
  }
</script>

<style lang="scss">
.tos-page {
  p {
    opacity: 1;
  }

  h2 {
    font-size: 1.5rem;
    text-transform: uppercase;
    font-weight: bold;
  }

  h3 {
    font-size: 1.3rem;
    font-weight: bold;
  }
}
</style>
