<template>
  <div class="home">
    <div class="hero-card">
      <div class="hero-card__content">
        <h1>
          Are you ready to find the best
          <span class="color-teal">free school</span>
          in Tarrant County?
        </h1>
        <p>*Currently supporting K-5</p>
        <nuxt-link to="/quiz" class="button">
          Yes! Start Quiz!
        </nuxt-link>
      </div>
    </div>
    <section class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-9 ml-auto mr-auto">
            <div class="row">
              <div class="col-md-7">
                <h2 id="about">
                  About Us
                </h2>
                <p>
                  <span itemprop="audience" itemscope itemtype="https://schema.org/audience">Parents</span>, have you wondered if there’s a better free school option out there for your child? <span itemprop="name" itemscope itemtype="https://schema.org/name">Schoolahoop</span> is here to help! It’s a fun, free app that helps you discover more K-5th school options based on what’s important for your child. Schoolahoop is in Beta and supports K-5th schools in Tarrant County only. We are just getting started and need your feedback. Thanks for helping us better serve local parents like you!
                </p>
              </div>
              <div class="col-md-5 text-center">
                <img itemprop="image" itemscope itemtype="https://schema.org/image" src="/hoops.svg" style="height: 200px;" alt="Two 'O's from the Schoolahoop school finder logo with confetti">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import Btn from '~/components/Btn'

export default {
  components: { Btn },
  mounted() {
    this.track()
    this.$store.commit('viewConfig/showFooterOnMobile')
  },
  methods: {
    track() {
      this.$mixpanel.track('Home page viewed', {
        step: this.name,
      })
    },
  },
}
</script>

<style lang="scss">
.home {
  h2 {
    color: $teal;
    font-weight: bold;
    font-size: 1.7rem;
  }

  p {
    opacity: 1;
    font-size: 1.1rem;
  }
}

.hero-card {
  background-color: $white;
  background-position: center right;
  background-repeat: no-repeat;
  background-size: contain;
  border-radius: 28px;
  max-width: 600px;
  margin: 10px auto;
  -webkit-box-shadow: 0px 6px 3px 0px rgba(37,32,79,0.2);
  box-shadow: 0px 6px 3px 0px rgba(37,32,79,0.2);

  @media(min-width: 576px) {
    background-image: url('/home-hero-emojis.svg');
    margin: 20px auto;
  }

  &__content {
    padding: 40px;
    text-align: left;

    h1 {
      margin: 0;
      max-width: 300px;
      font-size: 2.6rem;
      text-align: left;
    }

    p {
      opacity: 0.5;
    }
  }
}

.button {
  background-color: #ee7552;
  color: #fff;
  border-radius: 25px;
  padding: 10px 30px;
  border: none;
  font-weight: bold;
  margin: 10px 5px;
  font-size: 1.1rem;
  display: inline-block;
}

.button:hover {
  color: #fff;
}
</style>
