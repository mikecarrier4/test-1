<template>
  <div class="send-results text-center">
    <h1>
      We'll put you
      <span class="color-teal">in touch</span> with
      {{ numSchoolsChosenStr }}
    </h1>
    <p class="mw-420 mr-auto ml-auto">
      Please provide us with your email to be contacted back
    </p>
    <input
      v-model="fullName"
      type="text"
      placeholder="Your Full Name"
    >
    <input
      v-model="email"
      type="email"
      placeholder="Your Email"
    >
    <p class="color-red error-msg">
      {{ error }}
    </p>
    <btn
      label="Back"
      class="button button--outline red"
      style="padding-left:40px; padding-right:40px;"
      @clicked="goToResults"
    />
    <btn
      label="Continue"
      class="button button--outline mt-40"
      :disabled="hasErrors"
      @clicked="sendResults"
    />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import validate from 'validate.js'
import Btn from '~/components/Btn'

export default {
  components: { Btn },
  data() {
    return {
      email: '',
      fullName: '',
      error: '',
    }
  },
  computed: {
    hasErrors() {
      return !this.isValid()
    },
    ...mapGetters({
      numSchoolsChosenStr: 'user/numSchoolsChosenStr'
    }),
  },
  watch: {
    email(val) {
      this.storeInfo(val, 'email')
    },
    fullName(val) {
      this.storeInfo(val, 'fullName')
    },
  },
  methods: {
    sendResults() {
      this.$mixpanel.setAlias(this.email)

      this.$store.dispatch('user/sendEmail')
        .then(() => {
          this.$mixpanel.track('Email submitted', {
            error: false,
          })
          this.$router.push({ name: 'success' })
        })
        .catch(() => {
          this.$mixpanel.track('Email submitted', {
            error: true,
          })
          this.error = 'There was an error with your submission. If this issue persists, please contact us at contact@schoolahoop.org.'
        })
    },
    goToResults() {
      this.$router.push({ name: 'results' })
    },
    isValid() {
      const constraints = {
        email: { email: true },
        fullName: { presence: { allowEmpty: false } },
      }
      const errors = validate({
        email: this.email,
        fullName: this.fullName,
      }, constraints)

      if (errors) {
        this.errors = errors
        return false
      }

      this.errors = {}
      return true
    },
    storeInfo(val, name) {
      const obj = {
        key: name,
        value: val
      }

      this.$store.commit('user/update', obj)
    },
  },
  mounted() {
    this.$store.commit('viewConfig/hideFooterOnMobile')
  },
}
</script>

<style lang="scss">
.mail-img {
  margin: 20px auto;
  height: 180px;
}

.send-results {
  input {
    display: block;
    margin: 20px auto;
  }

  .error-msg {
    opacity: 1;
    max-width: 400px;
    margin: 10px auto;
  }
}
</style>
