<template>
  <div class="quiz-page">
    <div class="container">
      <div class="row">
        <div class="col ml-auto mr-auto">
          <quiz />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Quiz from '~/components/Quiz'

export default {
  components: { Quiz },
  computed: {
    getFields() {
      return this.$store.state.user.fields
    },
  },
  mounted() {
    this.$store.commit('viewConfig/hideFooterOnMobile')
  }
}
</script>

<style lang="scss">
.quiz-page {
  padding: 40px 0;
}
</style>
