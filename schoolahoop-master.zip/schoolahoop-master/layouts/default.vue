<template>
  <div>
    <navbar />
    <div class="wrapper">
      <nuxt />
    </div>
    <footer-nav :class="{ 'hidden-on-mobile': footerHiddenOnMobile }"/>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import Navbar from '~/components/Navbar'
import FooterNav from '~/components/FooterNav'

export default {
  components: { Navbar, FooterNav },
  computed: mapState({
    footerHiddenOnMobile: state => state.viewConfig.footerHiddenOnMobile,
  }),
}
</script>

<style lang="scss">
  @media(max-width: 600px) {
    .hidden-on-mobile {
      display: none;
    }
  }
</style>
