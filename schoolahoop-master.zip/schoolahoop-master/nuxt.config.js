
export default {
  mode: 'spa',
  /*
  ** Headers of the page
  */
  head: {
    __dangerouslyDisableSanitizers: ['script'],
    title: 'School Finder - Tarrant County, TX | Schoolahoop',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: 'Schoolahoop helps you find the best school in Tarrant County, TX based on what\'s important for your child. It is quick and completely free.' },
      { 'http-equiv': 'content-language', content: 'en-us' },
      { 'property': 'og:url', content: 'https://schoolahoop.org' },
      { 'property': 'og:title', content: 'School Finder - Tarrant County, TX | Schoolahoop' },
      { 'property': 'og:description', content: 'Schoolahoop helps you find the best school in Tarrant County, TX based on what\'s important for your child. It is quick and completely free.' },
      { 'property': 'og:image', content: 'https://schoolahoop.org/hoops.svg' },
      { 'property': 'og:type', content: 'website' },
    ],
    link: [
      { rel: 'icon', href: '/favicon-32.png', sizes: '32x32' },
      { rel: 'icon', href: '/favicon-57.png', sizes: '57x57' },
      { rel: 'icon', href: '/favicon-76.png', sizes: '76x76' },
      { rel: 'icon', href: '/favicon-96.png', sizes: '96x96' },
      { rel: 'icon', href: '/favicon-128.png', sizes: '128x128' },
      { rel: 'icon', href: '/favicon-192.png', sizes: '192x192' },
      { rel: 'icon', href: '/favicon-228.png', sizes: '228x228' },
      { rel: 'shortcut icon', href: '/favicon-196.png', sizes: '196x196' },
      { rel: 'apple-touch-icon', href: '/favicon-120.png', sizes: '120x120' },
      { rel: 'apple-touch-icon', href: '/favicon-152.png', sizes: '152x152' },
      { rel: 'apple-touch-icon', href: '/favicon-180.png', sizes: '180x180' },
      { rel: 'canonical', href: 'https://schoolahoop.org/' },
    ],
    __dangerouslyDisableSanitizers: ['script'],
    script: [
      { 
        innerHTML: `{ 
          "@context": {
            "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
            "xsd": "http://www.w3.org/2001/XMLSchema#"
          },
          "@type": "WebApplication",
          "@graph": [
            {
              "@id": "http://schema.org/WebApplication",
              "@type": "rdfs:Class",
              "rdfs:comment": "Web applications.",
              "rdfs:label": "WebApplication",
              "rdfs:subClassOf": {
                "@type": "Thing",
                "@id": "http://schema.org/SoftwareApplication"
              }
            }
          ],
          "name" : {
            "@type": "Thing",
            "@id": "http://schema.org/name",
            "value": "Schoolahoop"
          },
          "image" : {
            "@type": "Thing",
            "@id": "http://schema.org/image",
            "value": "/hoops.svg"
          },
          "audience" : {
            "@type": "CreativeWork",
            "@id": "http://schema.org/audience",
            "value": "Parents"
          }
        }`,
        type: 'application/ld+json' 
      },
      { src: '/tawk.js', body: true },
    ]
  },
  /*
  ** Customize the progress-bar color
  */
  loading: { color: '#fff' },
  /*
  ** Global CSS
  */
  css: [
    '~assets/scss/global.scss',
  ],
  /*
  ** Plugins to load before mounting the App
  */
  plugins: [
    '~/plugins/mixpanel',
    '~/plugins/tawk',
  ],
  /*
  ** Nuxt.js dev-modules
  */
  buildModules: [
    // Doc: https://github.com/nuxt-community/eslint-module
    // '@nuxtjs/eslint-module',
    '@nuxtjs/dotenv',
    ['@nuxtjs/gtm', {
      id: 'GTM-MGFW8LZ'
    }],
  ],
  /*
  ** Nuxt.js modules
  */
  modules: [
    // Doc: https://bootstrap-vue.js.org
    'bootstrap-vue/nuxt',
    // Doc: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios',
    '@nuxtjs/style-resources',
    '@nuxtjs/sitemap',
    '@nuxtjs/robots',
  ],
  /*
  ** Axios module configuration
  ** See https://axios.nuxtjs.org/options
  */

  /* Sitemap */
  sitemap: {
    hostname: 'https://schoolahoop.org',
    defaults: {
      changefreq: 'weekly',
      priority: 2,
      lastmod: new Date(),
      lastmodrealtime: true
    },
    routes: [
      {
        url: '/',
        changefreq: 'daily',
        priority: 1,
      },
    ],
    exclude: [
      '/admin',
      '/results',
      '/send-results',
      '/test',
      '/success',
    ],
  },

  robots: {
    Sitemap: 'https://schoolahoop.org/sitemap.xml',
    UserAgent: '*',
    Disallow: ['/admin', '/results', '/send-results', '/test', '/success']
  },

  axios: {
  },
  styleResources: {
    scss: ['~assets/scss/vars.scss'],
  },
  /*
  ** Build configuration
  */
  build: {
    /*
    ** You can extend webpack config here
    */
    extend(config, ctx) {
    }
  }
}
