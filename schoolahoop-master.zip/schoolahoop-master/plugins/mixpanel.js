import Vue from 'vue'
import mixpanel from 'mixpanel-browser'
import axios from 'axios'

mixpanel.init('d5e170d7845c09ea0654203e1426f251')

Vue.prototype.$mixpanel = {
  track: (eventName, obj) => {
	return axios.post('/.netlify/functions/filter_mixpanel').then((result) => {
	  	if (window.location.hostname.match(/schoolahoop.org/) !== null && result.data.filter === false) {
	  		mixpanel.track(eventName, obj)
	  	} else {
	  		mixpanel.register({"$ignore": true})
	  	}
	}).catch((err) => {
		console.log('get_ip err: ', err)

		axios.post('/.netlify/functions/email_error', {
			error: err
		}).then((data) => {
			data = data.data
			if (data.email_result === undefined || data.email_result === false) {
			  console.log('Error sending email: ', data)
			} else {
			  console.log('Error email was sent.')
			}
		}).catch((err) => {
			console.log('Error email could not be sent: ', err)
		})
	})
  },
  setAlias: (email) => {
    mixpanel.alias(email)
  },
}