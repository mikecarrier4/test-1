export const state = () => ({
  footerHiddenOnMobile: false,
})

export const mutations = {
  hideFooterOnMobile(state) {
    state.footerHiddenOnMobile = true
  },
  showFooterOnMobile(state) {
    state.footerHiddenOnMobile = false
  }
}