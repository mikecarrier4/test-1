import axios from 'axios'

const initializeFields = {
  name: '',
  grade: '',
  preferences: [],
  transportation: [],
  home_address: '',
  work_address: '',
  consider_commute: undefined,
  max_travel_time: '',
  chosen_school_ids: [],
  schools: [],
  email: '',
  fullName: '',
}

let formattedQuiz = {}
let filterResults = {}

export const state = () => ({
  fields: Object.assign(initializeFields, {})
})

export const mutations = {
  update(state, attr) {
    state.fields[attr.key] = attr.value
  },
  clear(state) {
    state.fields = Object.assign(initializeFields, {})
  },
  add(state, attr) {
    state.fields[attr.key].push(attr.value)
  },
  removeFromArr(state, attr) {
    const arr = state.fields[attr.key]

    for (let i = 0; i < arr.length; i++) {
      if (arr[i] === attr.value) {
        arr.splice(i, 1)
      }
    }
  },
}

export const actions = {
  sendQuizData({ commit, state }) {
    return (
      axios.post('/.netlify/functions/filter_schools', JSON.stringify({
        form_results: state.fields
      })).then((results) => {

        commit('update', {
          key: 'chosen_school_ids',
          value: [],
        })

        if (results && results.data) {
          const schools = results.data.schools

          formattedQuiz = results.data.form_results
          filterResults = results.data.schools

          commit('update', {
            key: 'schools',
            value: schools,
          })

          // commit('update', {
          //   key: 'chosen_school_ids',
          //   value: schools.map(s => s.id),
          // })
        }

        return Promise.resolve(true)
      }).catch((err) => {
        if (err.response.status >= 410 && err.response.status < 420) {
          console.log('Error has already been emailed: ', err)
        } else {
          console.log('Error has not been emailed.  Attempting now: ', err)
          axios.post('/.netlify/functions/email_error', {
            error: err
          }).then((data) => {
            data = data.data
            if (data.email_result === undefined || data.email_result === false) {
              console.log('Error sending email: ', data)
            } else {
              console.log('Error email was sent.')
            }
          }).catch((err) => {
            console.log('Error email could not be sent: ', err)
          })
        }
      })
    )
  },
  sendEmail({ commit, state }) {
    const params = {
      email: state.fields.email,
      fullName: state.fields.fullName,
      childName: state.fields.name,
      grade: state.fields.grade,
      travelMode: state.fields.transportation,
      preferences: state.fields.preferences,
      homeAddress: state.fields.home_address,
      chosen_school_ids: state.fields.chosen_school_ids,
    }
    if (formattedQuiz !== undefined) {
      params.formattedQuiz = formattedQuiz
      params.filterResults = filterResults
    }
    return axios.post('/.netlify/functions/contact_schools', JSON.stringify(params)).then((data) => {
      return true
    }).catch((err) => {
      if (err.response.status >= 410 && err.response.status < 420) {
        console.log('Error has already been emailed: ', err)
      } else {
        console.log('Error has not been emailed.  Attempting now: ', err)
        axios.post('/.netlify/functions/email_error', {
          error: err
        }).then((data) => {
          data = data.data
          if (data.email_result === undefined || data.email_result === false) {
            console.log('Error sending email: ', data)
          } else {
            console.log('Error email was sent.')
          }
        }).catch((err) => {
          console.log('Error email could not be sent: ', err)
        })
      }
      throw err.response.status
    })
  },
}

export const getters = {
  fields: state => key => state.fields[key],
  gradeName: (state) => {
    const grade = state.fields.grade

    if (grade === 'K') {
      return 'Kindergarten'
    }

    return `${grade} grade`
  },
  numSchoolsChosen: state => state.fields.chosen_school_ids.length,
  numSchoolsChosenStr: (state, getters) => {
    let str = ''
    const num = getters.numSchoolsChosen

    str += `${num} `

    if (num === 1) {
      str += 'school'
    } else {
      str += 'schools'
    }

    return str
  },
}
