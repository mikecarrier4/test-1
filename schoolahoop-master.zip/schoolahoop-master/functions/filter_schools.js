const faunadb = require('faunadb')
const fetch = require('node-fetch-polyfill')
const dateFormat = require('dateformat');

const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_KEY);

// const geolib = require('geolib'); // temp, to compare with fql calculations

const Geocodio = require('geocodio-library-node')
const geocodio = new Geocodio(process.env.GEOCODIO_KEY)

const q = faunadb.query

exports.handler = async (event, context) => {

    var site_context = event.headers.origin

    var EmailError = async function(error) {
        var mail_params = {
            to: process.env.EMAIL_ERRORS.split(','),
            from: process.env.FROM_EMAIL,
            subject: 'Schoolahoop: An Error has Occurred',
            text: "Error details: " + JSON.stringify(error),
            html: "Error details: " + JSON.stringify(error),
        }

        if (site_context.match(/schoolahoop.org/) != null) {
            return await sgMail.send(mail_params).then((data) => {
                return true
            }).catch((err) => {
                return err
            });
        } else {
            return true
        }
    }

    try {
        var params = JSON.parse(event.body)

        var form_results = {}
        var quiz_record = {}
        var destinations = []
        var school_count = 0
        var urls = []
        var url_count = 0
        var destination_string = ''
        var school_batches = []
        var schools = []
        var all_schools_by_id = {}
        var included_schools_by_id = {}
        var unsorted_schools = {}
        var sorted_schools = []
        var all_schools = []
        var total_school_count = 0
        var school_distances = []
        var dm_count = 0
        var travel_mode_count = 0
        var distancematrix_url = "https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial"
        var FindSchools_attempts = 0
        var travel_times = {}
        var errors = []
        var error_count = 0
        var independent_count = 0
        var logger = []

        var FormatQuizData = async function(form_results){
            var default_preferences = [ 
                'top_20_safety',
                'top_20_score',
                'school_bus_available',
                'diversity',
                'non_religious',
                'religious',
                'no_spanking',
                'after_school_care',
                'special_needs_education',
                'gifted_student_programs',
                'english_as_second_language',
                'k12_school',
                'school_library',
                'foreign_languages',
                'theater',
                'dance',
                'vegan_vegetarian',
                'visual_arts',
                'computer_science',
                'music',
                'sports',
                'healthy_lunch_options',
                'science',
            ]

            var appendLeadingZeroes = function(n){
                if(n <= 9){
                    return "0" + n
                }
                return n
            }

            var travel_minutes = form_results.max_travel_time.match(/[0-9]+/)
            if (travel_minutes != null) {
                max_travel_time = parseInt(travel_minutes[0])
            } else {
                max_travel_time = 120
            }

            var quiz_record = {
                'name': form_results.name,
                'grade': form_results.grade, 
                'preferences': {},
                'transportation' : form_results.transportation,
                'home_address' : form_results.home_address,
                'work_address' : form_results.work_address,
                'max_travel_time' : max_travel_time,
                'consider_commute' : form_results.consider_commute,
            }

            await geocodio.geocode(form_results.home_address, ['school'])
                .then(response => {
                    quiz_record.home_district = response.results[0].fields.school_districts.unified.name.replace('Independent School District','ISD')
                    quiz_record.home_coordinates = {}
                    quiz_record.home_coordinates.x = response.results[0].location.lng
                    quiz_record.home_coordinates.y = response.results[0].location.lat
                }).catch(err => {
                    errors[error_count] = err
                    error_count++
                    // console.log(err)
                }
            )

            if (form_results.work_address != undefined && form_results.work_address.trim() != '') {
                await geocodio.geocode(form_results.work_address)
                    .then(response => {
                        quiz_record.work_coordinates = {}
                        quiz_record.work_coordinates.x = response.results[0].location.lng
                        quiz_record.work_coordinates.y = response.results[0].location.lat
                    }).catch(err => {
                        errors[error_count] = err
                        error_count++
                        // console.log(err)
                    }
                )
            }

            form_results.preferences.forEach(function(preference){
                if (preference.match(/^custom:/)) {
                    var preference_string = preference.replace(/^custom:/,'')
                    if (quiz_record.preferences['custom'] == undefined) {
                        quiz_record.preferences['custom'] = ''
                    } else {
                        preference_string = "\n"+preference_string
                    }
                    quiz_record.preferences['custom'] += preference_string
                } else {
                    default_preferences.forEach(function(defined_preference){
                        if (preference == defined_preference) {
                            quiz_record.preferences[preference] = true
                        }
                    })
                }
            })

            default_preferences.forEach(function(preference){
                if (quiz_record.preferences[preference] == undefined) {
                    quiz_record.preferences[preference] = false
                }
            })

            return quiz_record
        }

        var SaveQuiz = async function(quiz){
            const client = new faunadb.Client({
                secret: process.env.FAUNADB_SERVER_SECRET
            })

            return await client.query(
                q.Create(
                    q.Collection("school_queries"),
                    {
                        data: quiz
                    }
                )
            ).then((res) => {
                form_results.ref = res.ref.id
                return true
            }).catch((error) => {
                return false
            })
        }

        var SortSchools = function(u_schools){
            var s_schools = []
            var final_array = []
            var school_counts = {}
            var school_register = {}

            var school_distances = {}

            Object.keys(u_schools).forEach(function(key, index){
                school_distances[u_schools[key].distance + '-' + u_schools[key].id] = true
            })

            u_keys = Object.keys(school_distances)

            u_keys.sort(function(a,b){
                a = parseFloat(a.split('-')[0])
                b = parseFloat(b.split('-')[0])
                return a - b
            }).forEach(function(key, index) {
                var school_id = key.split('-')[1]
                s_schools[s_schools.length] = u_schools[school_id]
            })

            s_schools.forEach(function(school,index){
                if (school_register[school.id] == undefined) {
                    var excluded = false

                    if (school.type.toUpperCase() == 'INDEPENDENT') {
                        if (independent_count >= 3) {
                            excluded = true
                        }
                    }

                    if (school_counts[school.id] == undefined) {
                        school_counts[school.id] = 0
                    }
                    school_counts[school.id]++

                    if (!excluded) {
                        if (school.type.toUpperCase() == 'INDEPENDENT') {
                            independent_count++
                        }

                        final_array[final_array.length] = school
                    }

                    school_register[school.id] = true
                }
            })

            return final_array
        }

        var GetDistanceMatrix = async function(urls, school_batches, max_travel_time, travel_modes, origin_strings, destination_strings) {
            // logger[logger.length] = 'GetDistanceMatrix 1'
            // logger[logger.length] = 'dm_count: ' + dm_count

            try {
                
                if (travel_modes[travel_mode_count] != undefined && urls[dm_count] != undefined) {
                    urls[dm_count] += "&mode="+travel_modes[travel_mode_count]

                    var origin_string = origin_strings[dm_count]
                    var destination_string = destination_strings[dm_count]
                    var travel_mode = travel_modes[travel_mode_count]
                    var url = 'https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins='+origin_string+'&destinations='+destination_string+'&mode='+travel_mode+'&key='+process.env.DISTANCEMATRIX_KEY

                    // url = 'https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=40.6655101,-73.89188969999998&destinations=40.6905615%2C-73.9976592%7C40.6905615%2C-73.9976592%7C40.6905615%2C-73.9976592%7C40.6905615%2C-73.9976592%7C40.6905615%2C-73.9976592%7C40.6905615%2C-73.9976592%7C40.659569%2C-73.933783%7C40.729029%2C-73.851524%7C40.6860072%2C-73.6334271%7C40.598566%2C-73.7527626%7C40.659569%2C-73.933783%7C40.729029%2C-73.851524%7C40.6860072%2C-73.6334271%7C40.598566%2C-73.7527626&key=XXXXXXXXXX'
                    // logger[logger.length] = 'GetDistanceMatrix 2'
                    var data = {}

                    try {
                        res = await fetch(url, {
                            method: 'GET'
                        })
                        data = await res.json()
                    } catch(err) {

                        var result = {message:"Distance Matrix API has failed.",form_results:form_results,dm_data:data,error:err,logger:logger,url:url}
                        result.email_result = await EmailError(result)

                        return {
                            statusCode:410,
                            body:JSON.stringify(result)
                        }
                    }


                    if (data.rows != undefined && data.rows.length > 0) {
                        // logger[logger.length] = 'GetDistanceMatrix 3'
                        data.rows.forEach(function(row){
                            var count = 0
                            row.elements.forEach(function(element){
                                // logger[logger.length] = 'GetDistanceMatrix 3.1'
                                // logger[logger.length] = 'count: ' + count

                                if (school_batches[dm_count][count].travel_time == undefined) {
                                    school_batches[dm_count][count].travel_time = {}
                                }

                                if (element.duration != undefined && element.duration.value != undefined && element.distance != undefined && element.distance.value != undefined) {
                                    // logger[logger.length] = 'GetDistanceMatrix 3.2'

                                    var time = Math.round((element.duration.value / 60) * 100) / 100 // seconds converted to minutes, and rounded
                                    var distance = Math.round((element.distance.value * 0.000621371) * 100) / 100 // feet converted to miles and rounded

                                    if (school_batches[dm_count][count].distance == undefined || school_batches[dm_count][count].distance > distance) {
                                        school_batches[dm_count][count].distance = distance
                                    }

                                    // logger[logger.length] = 'travel_mode: ' + travel_modes[travel_mode_count]
                                    school_batches[dm_count][count].travel_time[travel_modes[travel_mode_count]] = {
                                        'time' : time,
                                        'distance' : distance,
                                    }

                                    // let result = geoLib.distance({
                                    //     p1: { lat: 70.3369224, lon: 30.3411273 },
                                    //     p2: { lat: 59.8939528, lon: 10.6450348 }
                                    // });

                                    // school_batches[dm_count][count].geolib_params = {
                                    //     p1: { lat: form_results.home_coordinates.y, lon: form_results.home_coordinates.x },
                                    //     p2: { lat: school_batches[dm_count][count].Y, lon: school_batches[dm_count][count].X }
                                    // }

                                    // school_batches[dm_count][count].geolib = geoLib.distance(school_batches[dm_count][count].geolib_params);

                                    // school_batches[dm_count][count].geolib_meters = geolib.getDistance(
                                    //     { latitude: form_results.home_coordinates.y, longitude: form_results.home_coordinates.x },
                                    //     { latitude: school_batches[dm_count][count].Y, longitude: school_batches[dm_count][count].X }
                                    // );
                                    // school_batches[dm_count][count].geolib_miles = school_batches[dm_count][count].geolib_meters * 0.000621371
                                    // school_batches[dm_count][count].home_coord = form_results.home_coordinates
                                    // school_batches[dm_count][count].geolib_miles = school_batches[dm_count][count].geolib.distance * 0.621371
                                } else {
                                    logger[logger.length] = "travel_mode '"+travel_modes[travel_mode_count]+"' specifications could not be defined for school."
                                    logger[logger.length] = "element"
                                    logger[logger.length] = element
                                }
                                count++
                            })
                        })
                        // logger[logger.length] = 'GetDistanceMatrix 4'
                        school_batches[dm_count].forEach(function(school, index){
                            logger[logger.length] = 'index: ' + index

                            // logger[logger.length] = 'GetDistanceMatrix 4.1'
                            var excluded = false

                            // final distance filter
                            if (school.travel_time != undefined && school.travel_time[travel_modes[travel_mode_count]] != undefined && school.travel_time[travel_modes[travel_mode_count]].time != undefined && school.travel_time[travel_modes[travel_mode_count]].time > max_travel_time && max_travel_time != 0) {
                                // logger[logger.length] = 'GetDistanceMatrix 4.2'
                                excluded = true
                                // logger[logger.length] = 'GetDistanceMatrix 4.21'
                                // if (school.name == 'Chisholm Ridge') {
                                //     logger[logger.length] = "'"+school.name+"': excluded by final district filter: school.travel_time["+travel_modes[travel_mode_count]+"].time: "+school.travel_time[travel_modes[travel_mode_count]].time+", max_travel_time: "+max_travel_time
                                // }
                            }

                            // logger[logger.length] = 'GetDistanceMatrix 4.3'
                            if (!excluded) {

                                // logger[logger.length] = 'GetDistanceMatrix 4.4'
                                if (all_schools_by_id[school.id] != undefined) {
                                    travel_modes.forEach(function(mode){
                                        if (all_schools_by_id[school.id].travel_time[mode] != undefined) {
                                            school.travel_time[mode] = all_schools_by_id[school.id].travel_time[mode]
                                        }
                                    })
                                }

                                unsorted_schools[school.id] = school

                                included_schools_by_id[school.id] = school
                            }
                            // logger[logger.length] = 'GetDistanceMatrix 4.5'
                            total_school_count++
                            all_schools_by_id[school.id] = school
                        })
                        // logger[logger.length] = 'GetDistanceMatrix 5'
                        dm_count++
                    } else {

                        logger[logger.length] = 'No results from Distance Matrix server.'

                        var result = {schools:[],errors:["No results from Distance Matrix server.",data],form_results:form_results,logger:logger,url:url}
                        result.email_result = await EmailError(result)

                        return {
                            statusCode:411,
                            body:JSON.stringify(result)
                        }
                    }

                    if (urls[dm_count] != undefined) {
                        return await GetDistanceMatrix(urls, school_batches, max_travel_time, travel_modes, origin_strings, destination_strings)
                    } else {
                        travel_mode_count++
                        if (travel_modes[travel_mode_count] != undefined) {
                            dm_count = 0
                            return await GetDistanceMatrix(urls, school_batches, max_travel_time, travel_modes, origin_strings, destination_strings)
                        } else {
                            // logger[logger.length] = 'GetDistanceMatrix success'
                            var sorted_schools = SortSchools(unsorted_schools)

                            var result = {}
                            result.schools = sorted_schools
                            
                            // if (logger.length > 0) {
                            //     result.logger = logger
                            // }
                            result.form_results = form_results
                            return {
                                statusCode:201,
                                body:JSON.stringify(result)
                            }
                        }
                    }
                } else {

                    var sorted_schools = SortSchools(unsorted_schools)

                    var result = {}
                    result.schools = sorted_schools
                    // result.school_counts = school_counts
                    // if (logger.length > 0) {
                    //     result.logger = logger
                    // }
                    result.form_results = form_results
                    return {
                        statusCode: 202,
                        body: JSON.stringify(result)
                    }
                }
            } catch(err) {
                logger[logger.length] = "GetDistanceMatrix err:"
                logger[logger.length] = err
                throw err
            }
        }

        var ordinal_suffix_of = function(i) {
            var j = i % 10,
                k = i % 100
            if (j == 1 && k != 11) {
                return i + "st"
            }
            if (j == 2 && k != 12) {
                return i + "nd"
            }
            if (j == 3 && k != 13) {
                return i + "rd"
            }
            return i + "th"
        }

        var formatDate = function(date) {
            var monthNames = [
                "January", "February", "March",
                "April", "May", "June", "July",
                "August", "September", "October",
                "November", "December"
            ]

            return dateFormat(date, 'mmm dS, yyyy')
        }

        var FindSchools = async function(origins, max_travel_time, travel_modes) {
            school_batches = []
            url_count = 0
            dm_count = 0

            logger[logger.length] = 'FindSchools 1'

            var urls = []
            var school_batch = []
            if (typeof origins == 'object') {
                var origins = origins.join('|')
                var origins = encodeURI(origins.replace(/\s+/g,'+'))
            }
            var origin_strings = []
            var destination_string = ''
            var destination_strings = []
            var count = 0

            // an conversion from time to distance
            // based on an assumption of how fast the user is travelling 
            var mph_assumption = 45
            var max_distance = (max_travel_time / 60) * mph_assumption


            const client = new faunadb.Client({
                secret: process.env.FAUNADB_SERVER_SECRET
            })

            if (form_results.work_coordinates != undefined && form_results.work_coordinates.x != undefined) {
                var work_coordinates = form_results.work_coordinates
            } else {
                var work_coordinates = {x:-1, y:-1}
            }

            logger[logger.length] = 'FindSchools 2'

            if (form_results.home_coordinates !== undefined && form_results.home_coordinates.x !== undefined && form_results.home_coordinates.y !== undefined) {
                return await client.query(
                    q.Filter(
                        q.Map(
                            q.Paginate(
                                q.Match(q.Index("all_schools")),
                                {size:100000},
                            ),
                            q.Lambda(
                                "school",
                                q.Select(
                                    0,
                                    q.Map(
                                        [[q.Get(q.Var("school")), 3.141592653589, form_results.home_coordinates, work_coordinates]],
                                        q.Lambda(
                                            ["school","pi","home_coordinates","work_coordinates"],
                                            q.Merge(
                                                q.Select('data',q.Var("school")),
                                                {
                                                    "id" : q.Select(['ref','id'],q.Var("school")),
                                                    "home_coordinates" : q.Var("home_coordinates"),
                                                    "work_coordinates" : q.Var("work_coordinates"),
                                                    "max_distance" : max_distance,
                                                    "distance_from_home" : q.Multiply( // "distance_from_home" stands for "distance, local calculation", returns miles
                                                        q.Multiply(
                                                            q.Acos(
                                                                q.Add(
                                                                    q.Multiply(
                                                                        q.Sin(
                                                                            q.Multiply(
                                                                                q.Var('pi'),
                                                                                q.Divide(q.Select('y',q.Var("home_coordinates")),180)
                                                                            )
                                                                        ),
                                                                        q.Sin(
                                                                            q.Multiply(
                                                                                q.Var('pi'),
                                                                                q.Divide(q.Select(['data','Y'],q.Var("school")),180)
                                                                            )
                                                                        )
                                                                    ),
                                                                    q.Multiply(
                                                                        q.Cos(
                                                                            q.Multiply(
                                                                                q.Var('pi'),
                                                                                q.Divide(q.Select('y',q.Var("home_coordinates")),180)
                                                                            )
                                                                        ),
                                                                        q.Cos(
                                                                            q.Multiply(
                                                                                q.Var('pi'),
                                                                                q.Divide(q.Select(['data','Y'],q.Var("school")),180)
                                                                            )
                                                                        ),
                                                                        q.Cos(
                                                                            q.Multiply(
                                                                                q.Var('pi'),
                                                                                q.Divide(
                                                                                    q.Subtract(q.Select('x',q.Var("home_coordinates")), q.Select(['data','X'],q.Var("school"))),
                                                                                    180
                                                                                )
                                                                            )
                                                                        )
                                                                    )
                                                                )
                                                            ),
                                                            q.Divide(180,q.Var('pi'))
                                                        ),
                                                        60,
                                                        1.1515
                                                    ),
                                                    "distance_from_work" : q.If(
                                                        q.Equals(
                                                            q.Select('y',q.Var("work_coordinates")),
                                                            -1
                                                        ),
                                                        100000,
                                                        q.Multiply( // returns miles
                                                            q.Multiply(
                                                                q.Acos(
                                                                    q.Add(
                                                                        q.Multiply(
                                                                            q.Sin(
                                                                                q.Multiply(
                                                                                    q.Var('pi'),
                                                                                    q.Divide(q.Select('y',q.Var("work_coordinates")),180)
                                                                                )
                                                                            ),
                                                                            q.Sin(
                                                                                q.Multiply(
                                                                                    q.Var('pi'),
                                                                                    q.Divide(q.Select(['data','Y'],q.Var("school")),180)
                                                                                )
                                                                            )
                                                                        ),
                                                                        q.Multiply(
                                                                            q.Cos(
                                                                                q.Multiply(
                                                                                    q.Var('pi'),
                                                                                    q.Divide(q.Select('y',q.Var("work_coordinates")),180)
                                                                                )
                                                                            ),
                                                                            q.Cos(
                                                                                q.Multiply(
                                                                                    q.Var('pi'),
                                                                                    q.Divide(q.Select(['data','Y'],q.Var("school")),180)
                                                                                )
                                                                            ),
                                                                            q.Cos(
                                                                                q.Multiply(
                                                                                    q.Var('pi'),
                                                                                    q.Divide(
                                                                                        q.Subtract(q.Select('x',q.Var("work_coordinates")), q.Select(['data','X'],q.Var("school"))),
                                                                                        180
                                                                                    )
                                                                                )
                                                                            )
                                                                        )
                                                                    )
                                                                ),
                                                                q.Divide(180,q.Var('pi'))
                                                            ),
                                                            60,
                                                            1.1515
                                                        )
                                                    )
                                                }
                                            )
                                        )
                                    )
                                )
                            )
                        ),
                        q.Lambda(
                            ["school"],
                            q.Or(
                                q.LT(q.Select('distance_from_home',q.Var("school")), max_distance),
                                q.LT(q.Select('distance_from_work',q.Var("school")), max_distance)
                            )
                        )
                    )
                ).then(async function(res) {

                    var models = {
                        school : [
                            'id',
                            'name',
                            'contact_1_name',
                            'contact_1_title',
                            'contact_1_email',
                            'image_name',
                            'buses_available',
                            'ethnicities',
                            'coed',
                            'student_teacher_ratio',
                            'start_time',
                            'end_time',
                            'school_number',
                            'address',
                            'county',
                            'state',
                            'district',
                            'districts_that_can_apply',
                            'type',
                            'enrollment_start',
                            'enrollment_end',
                            'application_period',
                            'zip',
                            'zip_extension',
                            'X',
                            'Y',
                            // 'DisplayX',
                            // 'DisplayY',
                            // 'Xmin',
                            // 'Xmax',
                            // 'Ymin',
                            // 'Ymax',
                            // 'ExInfo',
                            // 'district_phone',
                            // 'district_fax',
                            // 'district_email',
                            // 'district_website',
                            // 'district_superintendent',
                            // 'district_enrollment',
                            // 'instruction_type',
                            // 'phone',
                            // 'fax',
                            'website',
                            // 'principal',
                            'grade_range',
                            'enrollment',
                            'Status',
                            // 'test_scores_approaches',
                            'test_scores_meets',
                            // 'test_scores_masters',
                            'new_school',
                            // 'total_safety_violations',
                            // 'safety_violations_divided_by_population',
                            'safety_violations_scrubbed',
                            'tags',
                            'school_info',
                            'distance_from_home',
                            'distance_from_work',
                            'max_distance',
                        ],

                        ethnicities : [
                            'native_american',
                            'asian',
                            'hispanic',
                            'black',
                            'white',
                            'pacific_islander',
                            'multiracial',
                            // 'total_race',
                        ],

                        coed : [
                            'female_students',
                            'male_students',
                        ],

                        tags : [
                            'cost',
                            'grade_range'
                        ],

                        school_info : [
                            'safety',
                            'test_scores',
                            'enrollment'
                        ]
                    }

                    var data = res.data

                    var schools = []
                    var school_count = 0

                    data.forEach(function(school){
                        var sd = school

                        var s = {}

                        models.school.forEach(function(key){
                            if (models[key] != undefined) {
                                var k2_count = 0
                                models[key].forEach(function(k2){
                                    
                                    switch(key) {
                                        case 'tags':
                                            if (s[key] == undefined) {
                                                s[key] = []
                                            }
                                            switch(k2) {
                                                case 'cost':
                                                    s[key][k2_count] = '$ Free'
                                                    k2_count++
                                                break

                                                case 'grade_range':
                                                    var grade_info = sd.grade_range.split('-')
                                                    var grade_string = ''
                                                    var grade_min = 1000
                                                    var grade_max = 1000

                                                    if (typeof grade_info == 'object' && grade_info.length > 0) {
                                                        var int_present = false

                                                        grade_info.forEach(function(info, index){
                                                            switch(grade_info[index]) {
                                                                case 'EE':
                                                                case 'KG':
                                                                case 'EE KG':
                                                                case 'GK':
                                                                case 'PK':
                                                                    grade_info[index] = 'Kindergarten'
                                                                    if (index == 0) {
                                                                        grade_min = 0
                                                                    } else {
                                                                        grade_max = 0
                                                                    }
                                                                break

                                                                default:
                                                                    var int = parseInt(grade_info[index])
                                                                    if (int > 0) {
                                                                        int_present = true

                                                                        if (index == 0) {
                                                                            grade_min = int
                                                                        } else {
                                                                            grade_max = int
                                                                        }

                                                                        int = ordinal_suffix_of(int)
                                                                        grade_info[index] = int
                                                                    } else {
                                                                        grade_info[index] = grade_info[index]
                                                                    }
                                                            }
                                                        })

                                                        grade_string = grade_info.join(' - ')
                                                        if (int_present) {
                                                            grade_string += ' grade'
                                                        }
                                                    } else {
                                                        grade_string = sd.grade_range
                                                    }

                                                    s[key][k2_count] = grade_string
                                                    if (grade_min < 1000) {
                                                        s.grade_min = grade_min
                                                    }
                                                    if (grade_max < 1000) {
                                                        s.grade_max = grade_max
                                                    }
                                                    k2_count++
                                                break

                                                default:
                                                break
                                            }
                                        break

                                        case 'school_info':
                                            if (s[key] == undefined) {
                                                s[key] = []
                                            }
                                            
                                            switch(k2) {
                                                case 'enrollment':
                                                    s[key][k2_count] = sd.enrollment + ' Students'
                                                    k2_count++
                                                break

                                                case 'test_scores':
                                                    if (sd.test_scores_meets != undefined) {
                                                        var test_scores_meets = parseInt(sd.test_scores_meets)
                                                        if (test_scores_meets != 'NaN') {
                                                            if (test_scores_meets > 66) {
                                                                s[key][k2_count] = 'High Test Scores'
                                                            } else if(test_scores_meets > 33) {
                                                                s[key][k2_count] = 'Medium Test Scores'
                                                            } else {
                                                                s[key][k2_count] = 'Low Test Scores'
                                                            }
                                                            k2_count++
                                                        }
                                                    }
                                                break

                                                case 'safety':
                                                    if (sd.safety_violations_scrubbed != undefined && sd.safety_violations_scrubbed != '') {
                                                        var safety_violations_scrubbed = parseFloat(sd.safety_violations_scrubbed)
                                                        if (safety_violations_scrubbed != 'NaN') {
                                                            if (safety_violations_scrubbed < 0.08211978221) {
                                                                s[key][k2_count] = 'Safe School'
                                                            } else if(safety_violations_scrubbed < 0.1941391941) {
                                                                s[key][k2_count] = 'Medium Safety Risk'
                                                            } else {
                                                                s[key][k2_count] = 'Low Safety School'
                                                            }
                                                            k2_count++
                                                        }
                                                    }
                                                break

                                                default:
                                                break
                                            }
                                        break

                                        default:
                                            if (sd[k2] != undefined && sd[k2] != null && sd[k2] != '') {
                                                if (s[key] == undefined) {
                                                    s[key] = {}
                                                }
                                                s[key][k2] = sd[k2]
                                            }
                                        break
                                    }
                                })
                            } else {
                                switch(key) {
                                    case 'image_name':
                                        if (sd[key] != undefined && sd[key] != null && sd[key] != '') {
                                            s[key] = 'https://storage.googleapis.com/schoolahoop-assets/'+sd[key]+'.jpg'
                                        }
                                    break

                                    case 'application_period':
                                        if (sd.enrollment_start != undefined && sd.enrollment_end != undefined) {
                                            var enrollment_start = Date.parse(sd.enrollment_start)
                                            var enrollment_end = Date.parse(sd.enrollment_end)
                                            var now = Date.now()

                                            if (enrollment_start != null && !enrollment_start.isNaN
                                                && enrollment_end != null && !enrollment_end.isNaN) {

                                                var start_in_seconds = enrollment_start - now 

                                                var start_in_days = Math.ceil(start_in_seconds / (3600 * 24))

                                                var end_in_seconds = enrollment_end - now

                                                var end_in_days = Math.ceil(end_in_seconds / (3600 * 24))

                                                if (start_in_seconds < 0 && end_in_seconds > 0) {
                                                    // we are in the enrollment period
                                                    if (end_in_days < 10) {
                                                        // closing in less than ten days
                                                        s[key] = "About to close"
                                                    } else {
                                                        // closing in ten or more days
                                                        s[key] = "Open"
                                                    }
                                                } else if(start_in_seconds > 0) {
                                                    // closed, display opening date
                                                    var opening_date = formatDate(Date.parse(sd.enrollment_start))
                                                    s[key] = "Opens on " + opening_date
                                                } else if(end_in_seconds < 0) {
                                                    s[key] = "Closed"
                                                }
                                            } else if (enrollment_end != null && !enrollment_end.isNaN){
                                                var end_in_seconds = enrollment_end - now

                                                var end_in_days = Math.ceil(end_in_seconds / (3600 * 24))

                                                if (end_in_seconds < 0) {
                                                    s[key] = "Closed"
                                                } else if (end_in_days < 10) {
                                                    // closing in less than ten days
                                                    s[key] = "About to close"
                                                }
                                            } else if(enrollment_start != null && !enrollment_start.isNaN) {
                                                var start_in_seconds = enrollment_start - now 

                                                var start_in_days = Math.ceil(start_in_seconds / (3600 * 24))

                                                if (start_in_seconds > 0) {
                                                    var opening_date = formatDate(Date.parse(sd.enrollment_start))
                                                    s[key] = "Opens on " + opening_date
                                                }
                                            }
                                        }
                                    break

                                    default:
                                        if (sd[key] != undefined && sd[key] != null && sd[key] != '') {
                                            s[key] = sd[key]
                                        }
                                    break
                                }
                            }
                        })

                        var excluded = false

                        // grade filter
                        var grade_bits = form_results.grade.match(/[0-9]+/)
                        var child_grade = 0
                        if (grade_bits != null) {
                            child_grade = grade_bits[0]
                        }
                        if (s.grade_min != undefined && child_grade < s.grade_min) {
                            excluded = true
                        } else if (s.grade_max != undefined && child_grade > s.grade_max) {
                            excluded = true
                        }

                        // if (excluded && s.name == 'Chisholm Ridge') {
                        //     logger[logger.length] = "'"+s.name+"': excluded by grade filter: s.grade_min: "+s.grade_min+", s.grade_max: "+s.grade_max+", child_grade: "+child_grade
                        // }

                        var district_exclusion = false

                        // district filter
                        if (s.type.toUpperCase() != 'CHARTER') {
                            // public school filter
                            if (form_results.home_district.toUpperCase() != s.district.toUpperCase()) {
                                excluded = true
                                district_exclusion = true
                            }
                        } else {
                            // charter school filter
                            if (s.districts_that_can_apply != undefined && s.districts_that_can_apply != '') {
                                var districts = s.districts_that_can_apply.split(',')
                                var district_found = false
                                districts.forEach(function(district, index){
                                    if (district.trim().toUpperCase() == form_results.home_district.toUpperCase()) {
                                        district_found = true
                                    }
                                })

                                // temporary fix
                                if (!district_found && form_results.home_district.toUpperCase() == 'EAGLE MOUNTAIN-SAGINAW ISD') {
                                    districts.forEach(function(district, index){
                                        if (district.trim().toUpperCase() == 'EAGLE MT-SAGINAW ISD') {
                                            district_found = true
                                        }
                                    })
                                }

                                if (!district_found) {
                                    excluded = true
                                    district_exclusion = true
                                }
                            }
                        }

                        // if (district_exclusion && s.name == 'Chisholm Ridge') {
                        //     var name = s.name.substr(0,20)
                        //     logger[logger.length] = "'"+name+"': excluded by district filter: form_results.home_district: "+form_results.home_district+", s.district: "+s.district+", s.districts_that_can_apply: "+s.districts_that_can_apply
                        // }

                        if (!excluded) {
                            s.address_encoded = encodeURI(s.address.replace(/ /g,'+'))
                            destinations[count] = s.address_encoded
                            destination_string = destinations.join('|')
                            var url = distancematrix_url+'&origins='+origins+'&destinations='+destination_string
                            school_batch[count] = s
                            count++ 
                            if (url.length > 8000 || count >= 25) {
                                urls[url_count] = url
                                // logger[logger.length] = "adding new batch 1"
                                school_batches[url_count] = school_batch
                                origin_strings[url_count] = origins
                                destination_strings[url_count] = destination_string
                                url_count++
                                destinations = []
                                school_batch = []
                                count = 0
                            }

                            schools[school_count] = s
                            school_count++
                        }
                    })

                    if (destinations.length > 0) {
                        destination_string = destinations.join('|')
                        urls[url_count] = distancematrix_url+'&origins='+origins+'&destinations='+destination_string
                        school_batches[url_count] = school_batch
                        school_batch = []
                        destinations = []
                        count = 0
                        origin_strings[url_count] = origins
                        destination_strings[url_count] = destination_string
                        url_count++
                    }
                    // logger[logger.length] = 'FindSchools 4'
                    logger[logger.length] = 'school_batches: '
                    logger[logger.length] = school_batches
                    return await GetDistanceMatrix(urls, school_batches, max_travel_time, travel_modes, origin_strings, destination_strings)
                }).catch(async function(err) {
                    logger[logger.length] = 'FindSchools err:'
                    logger[logger.length] = err
                    FindSchools_attempts++
                    if (FindSchools_attempts < 5) {
                        return await FindSchools(origins, max_travel_time, travel_modes)
                    } else {

                        var result = {message:"FindSchools function cannot execute successfully.",form_results:form_results,logger:logger}
                        result.email_result = await EmailError(result)

                        return {
                            statusCode:412,
                            body:JSON.stringify(result)
                        }
                    }
                })
            } else {
                var result = {message:"No valid home address coordinates could be found.",form_results:form_results,logger:logger}
                result.email_result = await EmailError(result)

                return {
                    statusCode:415,
                    body:JSON.stringify(result)
                }
            }
        }

        form_results = await FormatQuizData(params.form_results)

        form_results.user_ip = event.headers['client-ip']

        await SaveQuiz(form_results)

        var origins = []
        var origin_count = 0
        if (form_results.home_address != undefined) {
            origins[origin_count] = form_results.home_address
            origin_count++
        }
        if (form_results.work_address != undefined) {
            origins[origin_count] = form_results.work_address
            origin_count++
        }

        var possible_modes = ['driving','walking','bicycling','transit']
        var mode_settings = {
            'driving': false,
            'walking': false,
            'bicycling': false,
            'transit': false,
        }
        
        form_results.transportation.forEach(function(mode){
            switch (mode) {
                case 'driving':
                    mode_settings.driving = true
                    break
                case 'public':
                    mode_settings.transit = true
                    break
                case 'school bus':
                    mode_settings.driving = true
                    break
                case 'walking':
                    mode_settings.walking = true
                    break
                case 'biking':
                    mode_settings.bicycling = true
                    break
            }
        })

        var travel_modes = []
        var count = 0
        possible_modes.forEach(function(mode){
            if (mode_settings[mode] == true) {
                travel_modes[count] = mode
                count++
            }
        })

        var max_travel_time = form_results.max_travel_time // minutes
        return await FindSchools(origins, max_travel_time, travel_modes)

    } catch(err) {

        var result = {message:"filter_schools.js has failed.",form_results:form_results,error:err.message,logger:logger}
        result.email_result = await EmailError(result)
        
        return {
            statusCode:413,
            body:JSON.stringify(result)
        }
    }
}