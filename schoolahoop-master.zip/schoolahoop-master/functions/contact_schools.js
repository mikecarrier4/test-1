const faunadb = require('faunadb')
const fetch = require('node-fetch-polyfill');

const q = faunadb.query

const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_KEY);

exports.handler = async function(event, context, callback) {

    var logger = []

    var site_context = event.headers.origin

    var EmailError = async function(error) {
        var mail_params = {
            to: process.env.EMAIL_ERRORS.split(','),
            from: process.env.FROM_EMAIL,
            subject: 'Schoolahoop: An Error has Occurred',
            text: "Error details: " + JSON.stringify(error),
            html: "Error details: " + JSON.stringify(error),
        }

        if (site_context.match(/schoolahoop.org/) != null) {
            return await sgMail.send(mail_params).then((data) => {
                return true
            }).catch((err) => {
                return err
            });
        } else {
            return true
        }
    }

    try {
        let data = JSON.parse(event.body);

        var school_ids = data.chosen_school_ids
        var parent_name = data.fullName
        var parent_first_name = parent_name.split(' ')[0]
        var parent_email = data.email
        var child_name = data.childName
        var child_first_name = child_name.split(' ')[0]
        var grade = data.grade
        var mode_array = data.travelMode
        var preferences = data.preferences
        var home_address = data.homeAddress

        if (grade == 'K') {
            grade = 'Kindergarten'
        } else if (grade.match(/[0-9]/)) {
            grade = grade + ' grade'
        }

        var grader = grade
        if (grade.match(/grade$/i)) {
            grader = grade + 'r'
        } else if(grade.match(/kindergarten$/i)) {
            grader = grade + 'er'
        }

        // var test_travel_modes = ['driving','public','school bus','walking','biking']
        // {{biking, driving, walking, taking public transit, and interested in taking the school bus}}

        var mode_settings = {
            'biking' : false,
            'driving' : false,
            'walking' : false,
            'public' : false,
            'school_bus' : false,
        }
        mode_array.forEach(function(mode){
            switch(mode){
                case "school bus":
                    mode_settings.school_bus = true
                break

                default:
                    if (mode_settings[mode] != undefined) {
                        mode_settings[mode] = true
                    }
                break
            }
        })

        var travel_strings = []

        if (mode_settings.biking == true) {
            travel_strings[travel_strings.length] = 'biking'
        }
        if (mode_settings.driving == true) {
            travel_strings[travel_strings.length] = 'driving'
        }
        if (mode_settings.walking == true) {
            travel_strings[travel_strings.length] = 'walking'
        }
        if (mode_settings.public == true) {
            travel_strings[travel_strings.length] = 'taking public transit'
        }
        if (mode_settings.school_bus == true) {
            travel_strings[travel_strings.length] = 'interested in taking the school bus'
        }

        var travel_string = ''
        travel_strings.forEach(function(string, index){
            if (travel_strings.length > 2) {
                if (index + 1 == travel_strings.length) {
                    string = ' or '+string
                } else {
                    string += ', '
                }
            } else {
                if (index == 1) {
                    string = ' or '+string
                }
            }

            travel_string += string
        })

        var preference_list = []
        preferences.forEach(function(pref){
            var string = ''
            switch(pref){
                case 'top_20_safety':
                    string = 'High Safety'
                break

                case 'top_20_score':
                    string = 'High Test Scores'
                break

                case 'school_bus_available':
                    string = 'Provided Transportation'
                break

                case 'diversity':
                    string = 'Diversity'
                break

                case 'non_religious':
                    string = 'No Religion in the Classroom'
                break

                case 'religious':
                    string = 'A Religious-Based Institution'
                break

                case 'no_spanking':
                    string = 'No Corporal Punishment'
                break

                case 'after_school_care':
                    string = 'After School Care'
                break

                case 'special_needs_education':
                    string = 'Special Needs Education'
                break

                case 'gifted_student_programs':
                    string = 'Gifted Student Programs'
                break

                case 'english_as_second_language':
                    string = 'English as a Second Language Programs'
                break

                case 'k12_school':
                    string = 'A Full Grade Range, K-12 School'
                break

                case 'school_library':
                    string = 'A School Library'
                break

                case 'foreign_languages':
                    string = 'Foreign Language Education'
                break

                case 'theater':
                    string = 'Theater Programs'
                break

                case 'dance':
                    string = 'Dance Programs'
                break

                case 'special_diet':
                    string = 'Accomodations for Special Diets'
                break

                case 'visual_arts':
                    string = 'Visual Arts Programs'
                break

                case 'computer_science':
                    string = 'Computer Science Programs'
                break

                case 'music':
                    string = 'Music Programs'
                break

                case 'sports':
                    string = 'Sports Programs'
                break

                case 'healthy_lunch_options':
                    string = 'Healthy Lunch Options'
                break

                case 'science':
                    string = 'Science Programs'
                break

                default:
                    string = pref
                break
            }

            preference_list[preference_list.length] = {"string":string}
        })

        var doc_queries = []
        school_ids.forEach(function(school_id, index){
            doc_queries[index] = q.Get(q.Ref(q.Collection('schools'), school_id))
        })

        var site_context = event.headers.origin

        if (site_context.match(/schoolahoop.org/) == null) {
            var test_emails = ['joey.livingston@gmail.com','joey.livingston@joinlincoln.org','jakekozloski@joinlincoln.org','jakozloski@gmail.com','ianp@mac.com','ian@joinlincoln.org']
            // var test_emails = ['joey.livingston@gmail.com','joey.livingston@joinlincoln.org']
        }

        var school_tests = []

        var personalizations = []

        var ContactSchools_attempts = 0

        var ContactSchools = async function(){

            const client = new faunadb.Client({
                secret: process.env.FAUNADB_SERVER_SECRET
            })
            
            return await client.query(doc_queries).then(async function(res){
                var email_count = 0
                res.forEach(function(school,index){
                    if (test_emails == undefined || test_emails[index] != undefined) { // temporary
                        school = school.data

                        // temporary email replacement for testing, so actual schools aren't contacted
                        if (test_emails != undefined && test_emails[index] != undefined) {
                            school.contact_1_email = test_emails[index]
                        }

                        personalizations[personalizations.length] = {
                            "to": [{
                                "email": school.contact_1_email,
                                "name": school.contact_1_name
                            }],
                            "cc": [{
                                "email": parent_email
                            }],
                            "dynamic_template_data": {
                                "contact_name": school.contact_1_name,
                                "school_name": school.name,
                                "parent_full_name": parent_name,
                                "parent_first_name": parent_first_name,
                                "child_name": child_name,
                                "child_first_name": child_first_name,
                                "grade": grade,
                                "grader": grader,
                                "home_address": home_address,
                                "travel_string": travel_string,
                                "preference_list": preference_list,
                            }
                        }

                        email_count++
                    }
                })

                var mail_params = {
                    "personalizations": personalizations,
                    "from": {
                        "email": process.env.FROM_EMAIL,
                        "name": "Schoolahoop"
                    },
                    "reply_to": {
                        "email": parent_email,
                        "name": parent_name
                    },
                    "template_id": "d-5ac244efe2854622b300ac74e5c16fd2"
                }

                var mail_result = await sgMail.send(mail_params);

                var result = {"result":"success","mail_params":mail_params,"mail_result":mail_result,"email_count":email_count}

                if (logger.length > 0) {
                    result.logger = logger
                }

                var school_count = school_ids.length

                if (site_context.match(/schoolahoop.org/) != null) {
                    var slack_message = `YAY!  A parent has contacted some schools!\nParent name: ${parent_name}\nEmail address: ${parent_email}\nNumber of schools chosen: ${school_count}`
                    var slack_url = 'https://hooks.slack.com/services/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'
                    slack_result = await fetch(slack_url, {
                        method: 'post',
                        body: JSON.stringify({"text":slack_message})
                    })
                }

                return {
                    statusCode: 201,
                    body: JSON.stringify(result)
                    // body: JSON.stringify({"result":"success"})
                }
            }).catch(async function(error) {
                ContactSchools_attempts++
                if (ContactSchools_attempts < 5) {
                    return await ContactSchools()
                } else {

                    var result = {message:"ContactSchools function failed to execute, retried 5 times.",quiz_results:quiz_results,error:error.message}
                    result['email_result'] = await EmailError(result)

                    return {
                        statusCode:410,
                        body:JSON.stringify(result)
                    }
                }
            })
        }

        var SaveQuiz = async function(quiz){
            const client = new faunadb.Client({
                secret: process.env.FAUNADB_SERVER_SECRET
            })

            var ref = quiz.ref
            delete quiz.ref

            return await client.query(
                q.Update(
                    q.Ref(q.Collection('school_queries'), ref),
                    { 
                        data: quiz 
                    }
                )
            ).then((res) => {
                return true
            }).catch((error) => {
                return false
            })
        }

        var quiz_results = data.formattedQuiz
        quiz_results.email = data.email
        quiz_results.child_name = data.childName
        quiz_results.parent_name = data.fullName
        quiz_results.chosen_school_ids = data.chosen_school_ids

        var filter_school_ids = []
        data.filterResults.forEach(function(school, index){
            filter_school_ids[filter_school_ids.length] = school.id
        })
        quiz_results.filter_school_ids = filter_school_ids
        quiz_results.user_ip = event.headers['client-ip']

        SaveQuiz(quiz_results)

        return await ContactSchools()
    } catch(err) {

        var result = {message:"contact_schools.js has failed.",error:err.message}
        result['email_result'] = await EmailError(result)

        return {
            statusCode:411,
            body:JSON.stringify(result)
        }
    }
}