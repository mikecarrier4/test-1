const axios = require('axios')

const { GOOGLE_PLACES_KEY } = process.env
const PLACES_BASE_API = `https://maps.googleapis.com/maps/api/place/autocomplete/json?key=${GOOGLE_PLACES_KEY}`

const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_KEY);

exports.handler = async (event, context) => {

    var EmailError = async function(error) {
        var mail_params = {
            to: process.env.EMAIL_ERRORS.split(','),
            from: process.env.FROM_EMAIL,
            subject: 'Schoolahoop: An Error has Occurred',
            text: "Error details: " + JSON.stringify(error),
            html: "Error details: " + JSON.stringify(error),
        }

        return await sgMail.send(mail_params).then((data) => {
            return true
        }).catch((err) => {
            return err
        });
    }

    const query = JSON.parse(event.body).query || ''
    const url = encodeURI(`${PLACES_BASE_API}&input=${query}`)

    try {
        const results = await axios.get(url)
        const predictions = results.data.predictions

        return {
            statusCode: 200,
            body: JSON.stringify(predictions.map(p => p.description)),
        }
    } catch (err) {

        var result = {message:"google_autocomplete.js has failed.",error:err.message}
        result['email_result'] = await EmailError(result)

        return {
            statusCode: 410,
            body:JSON.stringify(result)
        }
    }
}
