const axios = require('axios')

const { GOOGLE_PLACES_KEY } = process.env
const PLACES_BASE_API = `https://maps.googleapis.com/maps/api/place/autocomplete/json?key=${GOOGLE_PLACES_KEY}`

const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_KEY);

exports.handler = async (event, context) => {

    var data = JSON.parse(event.body)

    var error = data.error

    var mail_params = {
        to: process.env.EMAIL_ERRORS.split(','),
        from: process.env.FROM_EMAIL,
        subject: 'Schoolahoop: An Error has Occurred',
        text: "Error details: " + JSON.stringify(error),
        html: "Error details: " + JSON.stringify(error),
    }

    var site_context = event.headers.origin

    if (site_context.match(/schoolahoop.org/) != null) {
        return await sgMail.send(mail_params).then((data) => {
            var result = {message:"Error email sent.",email_result:true}

            return {
                statusCode: 210,
                body:JSON.stringify(result)
            }
        }).catch((err) => {
            var result = {message:"Error email failed to send.",email_result:false,error:err.message}

            return {
                statusCode: 450,
                body:JSON.stringify(result)
            }
        }); 
    } else {
        return {
            statusCode: 212,
            body:JSON.stringify({message:"Not live site.  No error sent.",email_result:false})
        }
    }
}
