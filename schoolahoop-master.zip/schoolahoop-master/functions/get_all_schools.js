const faunadb = require('faunadb')

const q = faunadb.query

exports.handler = async (event, context) => {

	var client = new faunadb.Client({
		secret: process.env.FAUNADB_SERVER_SECRET
    })

	return await client.query(
		q.Map(
			q.Paginate(
				q.Match(q.Index("all_schools")),
				{size:100000},
			),
			q.Lambda(
				"school",
				q.Get(q.Var("school"))
			)
		)
	).then((result) => {
		var data = result.data
		var schools = []
		data.forEach(function(school_result, index){
			var school = school_result.data
			school.id = school_result.ref.id
			schools[schools.length] = school
		})
		return {
	        statusCode:210,
	        body:JSON.stringify({schools:schools})
	    }
	}).catch(async function(err) {
        var result = {message:"get_all_schools.js cannot execute successfully.",error:err}

        return {
            statusCode:401,
            body:JSON.stringify(result)
        }
    })
}