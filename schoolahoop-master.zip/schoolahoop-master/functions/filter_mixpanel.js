exports.handler = async (event, context) => {

	const block_ips = ['73.57.51.201','100.2.25.135','73.88.95.173','95.136.34.107','67.160.238.153','108.227.76.100','2601:740:8200:5b:300b:a22:1543:590','2001:818:d865:9e00:ed22:5673:6379:3ded']

	let user_ip = event.headers['client-ip']

	let ip_match = false
  	block_ips.forEach((ip, index) => {
  		if (ip === user_ip) {
  			ip_match = true
  		}
  	})

	return {
        statusCode:210,
        body:JSON.stringify({filter:ip_match})
    }
}