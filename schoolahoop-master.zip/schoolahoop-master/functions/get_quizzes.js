const faunadb = require('faunadb')

const q = faunadb.query

exports.handler = async (event, context) => {

	var client = new faunadb.Client({
		secret: process.env.FAUNADB_SERVER_SECRET
    })

	return await client.query(
		q.Map(
			q.Paginate(
				q.Match(q.Index("all_school_queries")),
				{size:100000},
			),
			q.Lambda(
				"school_query",
				q.Get(q.Var("school_query"))
			)
		)
	).then((result) => {
		var data = result.data
		var quizzes = []
		data.forEach(function(quiz_result, index){
			var quiz = quiz_result.data
			quiz.id = quiz_result.ref.id
			quiz.ts = quiz_result.ts
			quizzes[quizzes.length] = quiz
		})
		return {
	        statusCode:210,
	        body:JSON.stringify({quizzes:quizzes})
	    }
	})
}