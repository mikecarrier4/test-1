# Schoolahoop

> Schoolahoop quiz

Nuxt (https://nuxtjs.org) app statically served on Netlify (https://netlify.com).

## Build Setup

``` bash
# install dependencies
$ yarn install

# serve with hot reload at localhost:3000
$ yarn dev

# generate static project
$ yarn generate
```

## Working with Netlify functions locally

``` bash
# Download Netlify CLI
npm install netlify-cli -g

# Connect project to Netlify
netlify login

# Run with local lambda server
netlify dev
```

## Services used

| Service                    | Function                   |
|----------------------------|----------------------------|
| Sendgrid                   | Sending email              |
| Google Places API          | Address autocomplete       |
| Fauna DB                   | Database storage           |
| Google Cloud Storage       | Image storage              |
| Geocodio                   | Address geocoding          |
| Google Distance Matrix API | Calculate distance by time |

The `Google Places API` and `Google Cloud Storage` can be managed from the Lincoln Google Cloud Console (https://cloud.google.com) under the **Schoolahoop** project